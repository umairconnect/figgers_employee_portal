﻿export function allowedAttachments() {

    let arrMessages = [];

    arrMessages["jpg"] = "jpg";
    arrMessages["bmp"] = "bmp";
    arrMessages["png"] = "png";
    arrMessages["PNG"] = "PNG";
    arrMessages["tif"] = "tif";
    arrMessages["jpeg"] = "jpeg";
    arrMessages["JPEG"] = "JPEG";
    arrMessages["xls"] = "xls";
    arrMessages["xlsx"] = "xlsx";
    arrMessages["txt"] = "txt";
    arrMessages["pdf"] = "pdf";
    arrMessages["xps"] = "xps";
    arrMessages["gif"] = "gif";
    arrMessages["doc"] = "doc";
    arrMessages["ppa"] = "ppa";
    arrMessages["ppt"] = "ppt";
    arrMessages["rtf"] ="rtf";
    
    return arrMessages;

}

