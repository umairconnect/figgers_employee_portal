import { makeStyles } from '@material-ui/core/styles';


export default makeStyles(theme => ({
    customBreadcrumbs: {
        "& svg": {
            margin: '0 0',
        },
        "& a": {
            fontStyle: 'normal',
            fontWeight: 400,
            fontSize: '14px',
            lineHeight: '17px',
            color: '#3C4549',
        }
    },
    parantLink: {
        fontWeight: 600,
        fontSize: '14px',
        lineHeight: '17px',
        color: '#3C4549',
    },
    childLink: {
        fontWeight: 400,
        fontSize: '14px',
        lineHeight: '17px',
        color: '#3C4549',
    }


}));