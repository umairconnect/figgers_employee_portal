import React, { useState, useEffect, useRef } from "react";
import useStyles from "./styles";
import {
    Breadcrumbs,
    Link
} from "@material-ui/core";

import ArrowRightIcon from '@material-ui/icons/ArrowRight';


import EmptyGrid from './../../assets/img/emptyGrid.svg';

export default function Breadcrums({ parentLink, currentLink, ...props }) {
    const classes = useStyles();
    return (
        <>
            <Breadcrumbs separator={<ArrowRightIcon />} aria-label="breadcrumb" className={classes.customBreadcrumbs}>

                <Link color="inherit" className="no-link" >
                    <span className={classes.parantLink}>{parentLink}</span>
                </Link>

                <Link color="inherit" className="no-link" >
                    <span className={classes.childLink}>  {currentLink}</span>
                </Link>

            </Breadcrumbs>
        </>
    )
}
