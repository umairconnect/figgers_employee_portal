import { makeStyles } from '@material-ui/core/styles';


export default makeStyles(theme => ({
    noRecord: {
        marginBottom: '5px',
        marginTop: '5px',
        textAlign: 'center',
        fontSize: '16px',
        "& img": {
          textAlign: 'center',
          justifyContent: 'center',
          display: 'flex',
          margin: '10px auto',
        }
      },
      noRecordText: {
         margin: '20px',
         color: 'rgba(0, 0, 0, 0.25)',
      }


}));