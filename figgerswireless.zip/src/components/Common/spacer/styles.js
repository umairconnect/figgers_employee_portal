import { makeStyles } from '@material-ui/core/styles';


export default makeStyles(theme => ({
    appBarSpacer: {
        minHeight: '82px',
        background: 'white',
    },
}));