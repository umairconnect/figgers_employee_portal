
export function GetCustomerData(methodName, apiParams) {
 
    return sessionStorage.getItem('customer_data');

}