import { Space, Tag } from 'antd';
import { formatDate, formatDateTime, formateMdnNumber } from '../../../src/components/Common/Extensions';
import { Tooltip } from 'antd';

export const data = {

    PostpaidWireless: [
        {
            title: '',
            dataIndex: 'wirelessId',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Status',
            dataIndex: 'status',
            className: "width120 textCenter",
            sorter: (a, b) => {
                a = a.status != null ? a.status.toString() : "";
                b = b.status != null ? b.status.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Sr',
            dataIndex: 'Sr',
            className: "width140",
            sorter: (a, b) => {
                a = a.Sr != null ? a.Sr.toString() : "";
                b = b.Sr != null ? b.Sr.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Phone Number',
            dataIndex: 'PhoneNumber',
            className: "width80",
            sorter: (a, b) => {
                a = a.PhoneNumber != null ? a.PhoneNumber.toString() : "";
                b = b.PhoneNumber != null ? b.PhoneNumber.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'ICC/SIM',
            dataIndex: 'sim',
            className: "width140",
            sorter: (a, b) => {
                a = a.sim != null ? a.sim.toString() : "";
                b = b.sim != null ? b.sim.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Name',
            dataIndex: 'name',
            className: "width120",
            sorter: (a, b) => {
                a = a.name != null ? a.name.toString() : "";
                b = b.name != null ? b.name.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: "Activated on",
            dataIndex: "activatedon",
            className: "width130",
            sorter: (a, b) => {
                a = a.activatedon != null ? a.activatedon.toString() : "";
                b = b.activatedon != null ? b.activatedon.toString() : "";
                return a.localeCompare(b);
            },
        },


        {
            title: 'Forwarded to',
            dataIndex: 'Forwardedto',
            className: "width150",
            sorter: (a, b) => {
                a = a.Forwardedto != null ? a.Forwardedto.toString() : "";
                b = b.Forwardedto != null ? b.Forwardedto.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Action',
            dataIndex: 'postpaidAction',
            fixed: "right",
            className: "width140 textCenter",
        },

    ],
    PrepaidWireless: [
        {
            title: '',
            dataIndex: 'wirelessId',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Status',
            dataIndex: 'statusCol',
            className: "width100 textCenter",
            sorter: (a, b) => {
                a = a.statusCol != null ? a.statusCol.toString() : "";
                b = b.statusCol != null ? b.statusCol.toString() : "";
                return a.localeCompare(b);
            },
        },

        {
            title: 'Phone Number',
            dataIndex: 'mDN',
            className: "width80",
            sorter: (a, b) => {
                a = a.mDN != null ? a.mDN.toString() : "";
                b = b.mDN != null ? b.mDN.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return formateMdnNumber(text);
            }
        },
        {
            title: 'ICC/SIM',
            dataIndex: 'iCC',
            className: "width140",
            sorter: (a, b) => {
                a = a.iCC != null ? a.iCC.toString() : "";
                b = b.iCC != null ? b.iCC.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Name',
            dataIndex: 'username',
            className: "width120",
            sorter: (a, b) => {
                a = a.username != null ? a.username.toString() : "";
                b = b.username != null ? b.username.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: "Activated on",
            dataIndex: "activationDate",
            className: "width130",
            sorter: (a, b) => {
                a = a.activationDate != null ? a.activationDate.toString() : "";
                b = b.activationDate != null ? b.activationDate.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return formatDateTime(text);

            }
        },

        {
            //ESN>Equipment Serial Number
            title: 'Device',
            dataIndex: 'eSN',
            className: "width140",
            sorter: (a, b) => {
                a = a.eSN != null ? a.eSN.toString() : "";
                b = b.eSN != null ? b.eSN.toString() : "";
                return a.localeCompare(b);
            },
        },

        {
            title: 'Forwarded to',
            dataIndex: 'Forwardedto',
            className: "width150",
            sorter: (a, b) => {
                a = a.Forwardedto != null ? a.Forwardedto.toString() : "";
                b = b.Forwardedto != null ? b.Forwardedto.toString() : "";
                return a.localeCompare(b);
            },
        },

        {
            title: 'Notes',
            dataIndex: 'customNoteHTML',
            className: "width150",
            sorter: (a, b) => {
                a = a.customNoteHTML != null ? a.customNoteHTML.toString() : "";
                b = b.customNoteHTML != null ? b.customNoteHTML.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Actions',
            dataIndex: 'prepaidAction',
            fixed: "right",
            className: "width140 textCenter",
        },

    ],
    PrepaidPackages: [
        {
            title: '',
            dataIndex: 'packageId',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Phone Number',
            dataIndex: 'phoneNumber',
            className: "width80",
            sorter: (a, b) => {
                a = a.phoneNumber != null ? a.phoneNumber.toString() : "";
                b = b.phoneNumber != null ? b.phoneNumber.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return formateMdnNumber(text);
            }
        },
        {
            title: 'Name',
            dataIndex: 'packageName',
            className: "width100",
            sorter: (a, b) => {
                a = a.packageName != null ? a.packageName.toString() : "";
                b = b.packageName != null ? b.packageName.toString() : "";
                return a.localeCompare(b);
            },
        },

        {
            title: 'Category',
            dataIndex: 'category',
            className: "width80",
            sorter: (a, b) => {
                a = a.category != null ? a.category.toString() : "";
                b = b.category != null ? b.category.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Behavior',
            dataIndex: 'behavior',
            className: "width140",
            sorter: (a, b) => {
                a = a.behavior != null ? a.behavior.toString() : "";
                b = b.behavior != null ? b.behavior.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Usage Type',
            dataIndex: 'usageType',
            className: "width120",
            sorter: (a, b) => {
                a = a.usageType != null ? a.usageType.toString() : "";
                b = b.usageType != null ? b.usageType.toString() : "";
                return a.localeCompare(b);
            },
        },
    ],
    PaymentHistory: [
        {
            title: '',
            dataIndex: 'id',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Date',
            dataIndex: 'date',
            className: "width80",
            sorter: (a, b) => {
                a = a.date != null ? a.date.toString() : "";
                b = b.date != null ? b.date.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return formatDate(text);
            }
        },
        {
            title: 'Amount',
            dataIndex: 'formattedAmount',
            className: "width80",
            sorter: (a, b) => {
                a = a.formattedAmount != null ? a.formattedAmount.toString() : "";
                b = b.formattedAmount != null ? b.formattedAmount.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Type',
            dataIndex: 'type',
            className: "width80",
            sorter: (a, b) => {
                a = a.type != null ? a.type.toString() : "";
                b = b.type != null ? b.type.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Description',
            dataIndex: 'description',
            className: "width140",
            sorter: (a, b) => {
                a = a.description != null ? a.description.toString() : "";
                b = b.description != null ? b.description.toString() : "";
                return a.localeCompare(b);
            },
        },

    ],
    UserDetails: [
        {
            title: '',
            dataIndex: 'userId',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Date /Time',
            dataIndex: 'Sr',
            className: "width140",
            sorter: (a, b) => {
                a = a.Sr != null ? a.Sr.toString() : "";
                b = b.Sr != null ? b.Sr.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Type',
            dataIndex: 'usageType',
            className: "width80",
            sorter: (a, b) => {
                a = a.usageType != null ? a.usageType.toString() : "";
                b = b.usageType != null ? b.usageType.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Destination Number',
            dataIndex: 'sim',
            className: "width140",
            sorter: (a, b) => {
                a = a.sim != null ? a.sim.toString() : "";
                b = b.sim != null ? b.sim.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Destination Operator',
            dataIndex: 'status',
            className: "width120",
            sorter: (a, b) => {
                a = a.status != null ? a.status.toString() : "";
                b = b.status != null ? b.status.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: "Duration",
            dataIndex: "name",
            className: "width130",
            sorter: (a, b) => {
                a = a.name != null ? a.name.toString() : "";
                b = b.name != null ? b.name.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Amount ($) ',
            dataIndex: 'amount',
            className: "width120",
            sorter: (a, b) => {
                a = a.amount != null ? a.amount.toString() : "";
                b = b.amount != null ? b.amount.toString() : "";
                return a.localeCompare(b);
            },
        },

        {
            title: 'Discount ($) ',
            dataIndex: 'discount',
            className: "width150",
            sorter: (a, b) => {
                a = a.discount != null ? a.discount.toString() : "";
                b = b.discount != null ? b.discount.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Net Amount ($)',
            dataIndex: 'netAmount',
            className: "width150",
            sorter: (a, b) => {
                a = a.netAmount != null ? a.netAmount.toString() : "";
                b = b.netAmount != null ? b.netAmount.toString() : "";
                return a.localeCompare(b);
            },
        },

    ],
    SMSDetails: [
        {
            title: '',
            dataIndex: 'userId',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Date /Time',
            dataIndex: 'column3',
            className: "width140",
            sorter: (a, b) => {
                a = a.column3 != null ? a.column3.toString() : "";
                b = b.column3 != null ? b.column3.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Destination Number',
            dataIndex: 'column2',
            className: "width140",
            sorter: (a, b) => {
                a = a.column2 != null ? a.column2.toString() : "";
                b = b.column2 != null ? b.column2.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: "Duration",
            dataIndex: "column4",
            className: "width130",
            sorter: (a, b) => {
                a = a.column4 != null ? a.column4.toString() : "";
                b = b.column4 != null ? b.column4.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Cost ($) ',
            dataIndex: 'column5',
            className: "width120",
            sorter: (a, b) => {
                a = a.column5 != null ? a.column5.toString() : "";
                b = b.column5 != null ? b.column5.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Call Plan ',
            dataIndex: 'column6',
            className: "width120",
            sorter: (a, b) => {
                a = a.column6 != null ? a.column6.toString() : "";
                b = b.column6 != null ? b.column6.toString() : "";
                return a.localeCompare(b);
            },
        },

    ],
    CallDetails: [
        {
            title: '',
            dataIndex: 'userId',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Date /Time',
            dataIndex: 'column1',
            className: "width140",
            sorter: (a, b) => {
                a = a.column1 != null ? a.column1.toString() : "";
                b = b.column1 != null ? b.column1.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Type',
            dataIndex: 'column2',
            className: "width80",
            sorter: (a, b) => {
                a = a.column2 != null ? a.column2.toString() : "";
                b = b.column2 != null ? b.column2.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Destination Number',
            dataIndex: 'column3',
            className: "width140",
            sorter: (a, b) => {
                a = a.column3 != null ? a.column3.toString() : "";
                b = b.column3 != null ? b.column3.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Destination Operator',
            dataIndex: 'column4',
            className: "width120",
            sorter: (a, b) => {
                a = a.column4 != null ? a.column4.toString() : "";
                b = b.column4 != null ? b.column4.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: "Duration",
            dataIndex: "column5",
            className: "width130",
            sorter: (a, b) => {
                a = a.column5 != null ? a.column5.toString() : "";
                b = b.column5 != null ? b.column5.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Amount ($) ',
            dataIndex: 'column6',
            className: "width120",
            sorter: (a, b) => {
                a = a.column6 != null ? a.column6.toString() : "";
                b = b.column6 != null ? b.column6.toString() : "";
                return a.localeCompare(b);
            },
        },

        //{
        //    title: 'Discount ($) ',
        //    dataIndex: 'discount',
        //    className: "width150",
        //    sorter: (a, b) => {
        //        a = a.discount != null ? a.discount.toString() : "";
        //        b = b.discount != null ? b.discount.toString() : "";
        //        return a.localeCompare(b);
        //    },
        //},
        //{
        //    title: 'Net Amount ($)',
        //    dataIndex: 'netAmount',
        //    className: "width150",
        //    sorter: (a, b) => {
        //        a = a.netAmount != null ? a.netAmount.toString() : "";
        //        b = b.netAmount != null ? b.netAmount.toString() : "";
        //        return a.localeCompare(b);
        //    },
        //},

    ],

    DataDetails: [
        {
            title: '',
            dataIndex: 'userId',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Date /Time',
            dataIndex: 'column3',
            className: "width140",
            sorter: (a, b) => {
                a = a.column3 != null ? a.column3.toString() : "";
                b = b.column3 != null ? b.column3.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Call From',
            dataIndex: 'column1',
            className: "width80",
            sorter: (a, b) => {
                a = a.column1 != null ? a.column1.toString() : "";
                b = b.column1 != null ? b.column1.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Call To',
            dataIndex: 'column2',
            className: "width140",
            sorter: (a, b) => {
                a = a.column2 != null ? a.column2.toString() : "";
                b = b.column2 != null ? b.column2.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: "Duration",
            dataIndex: "column4",
            className: "width130",
            sorter: (a, b) => {
                a = a.column4 != null ? a.column4.toString() : "";
                b = b.column4 != null ? b.column4.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Cost ($) ',
            dataIndex: 'column5',
            className: "width120",
            sorter: (a, b) => {
                a = a.column5 != null ? a.column5.toString() : "";
                b = b.column5 != null ? b.column5.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Call Plan ',
            dataIndex: 'column6',
            className: "width120",
            sorter: (a, b) => {
                a = a.column6 != null ? a.column6.toString() : "";
                b = b.column6 != null ? b.column6.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Data Used ',
            dataIndex: 'column7',
            className: "width120",
            sorter: (a, b) => {
                a = a.column7 != null ? a.column7.toString() : "";
                b = b.column7 != null ? b.column7.toString() : "";
                return a.localeCompare(b);
            },
        },

        //{
        //    title: 'Discount ($) ',
        //    dataIndex: 'discount',
        //    className: "width150",
        //    sorter: (a, b) => {
        //        a = a.discount != null ? a.discount.toString() : "";
        //        b = b.discount != null ? b.discount.toString() : "";
        //        return a.localeCompare(b);
        //    },
        //},
        //{
        //    title: 'Net Amount ($)',
        //    dataIndex: 'netAmount',
        //    className: "width150",
        //    sorter: (a, b) => {
        //        a = a.netAmount != null ? a.netAmount.toString() : "";
        //        b = b.netAmount != null ? b.netAmount.toString() : "";
        //        return a.localeCompare(b);
        //    },
        //},

    ],
    ActivityLog: [
        {
            title: '',
            dataIndex: 'userId',
            className: "custom-grid-hide-col",
        },
        //{
        //    title: 'Session ID',
        //    dataIndex: 'sessionId',
        //    className: "width140",
        //    sorter: (a, b) => {
        //        a = a.sessionId != null ? a.sessionId.toString() : "";
        //        b = b.sessionId != null ? b.sessionId.toString() : "";
        //        return a.localeCompare(b);
        //    },
        //},
        {
            title: 'Date/Time',
            dataIndex: 'activityDate',
            className: "width140",
            sorter: (a, b) => {
                a = a.activityDate != null ? a.activityDate.toString() : "";
                b = b.activityDate != null ? b.activityDate.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Account',
            dataIndex: 'accountNumber',
            className: "width120",
            sorter: (a, b) => {
                a = a.accountNumber != null ? a.accountNumber.toString() : "";
                b = b.accountNumber != null ? b.accountNumber.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'MDN Number',
            dataIndex: 'mdnNumber',
            className: "width140",
            sorter: (a, b) => {
                a = a.mdnNumber != null ? a.mdnNumber.toString() : "";
                b = b.mdnNumber != null ? b.mdnNumber.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'User',
            dataIndex: 'user',
            className: "width120",
            sorter: (a, b) => {
                a = a.user != null ? a.user.toString() : "";
                b = b.user != null ? b.user.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: "Activity",
            dataIndex: "details",
            className: "width180",
            sorter: (a, b) => {
                a = a.details != null ? a.details.toString() : "";
                b = b.details != null ? b.details.toString() : "";
                return a.localeCompare(b);
            },
        },


    ],
    AddNewSim: [
        {
            title: '',
            dataIndex: 'requestsId',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Sr#',
            dataIndex: 'sr',
            className: "width140",
            sorter: (a, b) => {
                a = a.sr != null ? a.sr.toString() : "";
                b = b.sr != null ? b.sr.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Order Number',
            dataIndex: 'orderNumber',
            className: "width80",
            sorter: (a, b) => {
                a = a.orderNumber != null ? a.orderNumber.toString() : "";
                b = b.orderNumber != null ? b.orderNumber.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Customer Information',
            dataIndex: 'customerInformation',
            className: "width140",
            sorter: (a, b) => {
                a = a.customerInformation != null ? a.customerInformation.toString() : "";
                b = b.customerInformation != null ? b.customerInformation.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Order Information',
            dataIndex: 'orderInformation',
            className: "width120",
            sorter: (a, b) => {
                a = a.orderInformation != null ? a.orderInformation.toString() : "";
                b = b.orderInformation != null ? b.orderInformation.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: "Order Status",
            dataIndex: "orderStatus",
            className: "width130",
        },
        {
            title: 'Action',
            dataIndex: 'requestAction',
            fixed: "right",
            className: "width140 textCenter",
        },
    ],
    customerNotes: [
        {
            title: 'Note',
            dataIndex: 'noteHTML',
            className: "width80",
            sorter: (a, b) => {
                a = a.noteHTML != null ? a.noteHTML.toString() : "";
                b = b.noteHTML != null ? b.noteHTML.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Added By',
            dataIndex: 'userName',
            className: "width40",
            sorter: (a, b) => {
                a = a.userName != null ? a.userName.toString() : "";
                b = b.userName != null ? b.userName.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Note Date',
            dataIndex: 'noteDate',
            className: "width40",
            sorter: (a, b) => {
                a = a.noteDate != null ? a.noteDate.toString() : "";
                b = b.noteDate != null ? b.noteDate.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Action',
            dataIndex: 'customerNotesAction',
            fixed: "right",
            className: "width140 textCenter",
        },



    ],
    ViewLog: [
        {
            title: '',
            dataIndex: 'userId',
            className: "custom-grid-hide-col",
        },
        //{
        //    title: 'Session ID',
        //    dataIndex: 'sessionId',
        //    className: "width140",
        //    sorter: (a, b) => {
        //        a = a.sessionId != null ? a.sessionId.toString() : "";
        //        b = b.sessionId != null ? b.sessionId.toString() : "";
        //        return a.localeCompare(b);
        //    },
        //},
        {
            title: 'Date/Time',
            dataIndex: 'activityDate',
            className: "width140",
            sorter: (a, b) => {
                a = a.activityDate != null ? a.activityDate.toString() : "";
                b = b.activityDate != null ? b.activityDate.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Account',
            dataIndex: 'accountNumber',
            className: "width120",
            sorter: (a, b) => {
                a = a.accountNumber != null ? a.accountNumber.toString() : "";
                b = b.accountNumber != null ? b.accountNumber.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'MDN Number',
            dataIndex: 'mdnNumber',
            className: "width140",
            sorter: (a, b) => {
                a = a.mdnNumber != null ? a.mdnNumber.toString() : "";
                b = b.mdnNumber != null ? b.mdnNumber.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return formateMdnNumber(text);
            }
        },
        {
            title: 'User',
            dataIndex: 'user',
            className: "width120",
            sorter: (a, b) => {
                a = a.user != null ? a.user.toString() : "";
                b = b.user != null ? b.user.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Type',
            dataIndex: 'type',
            className: "width120",
            sorter: (a, b) => {
                a = a.type != null ? a.type.toString() : "";
                b = b.type != null ? b.type.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: "Activity",
            dataIndex: "details",
            className: "width130",
            sorter: (a, b) => {
                a = a.details != null ? a.details.toString() : "";
                b = b.details != null ? b.details.toString() : "";
                return a.localeCompare(b);
            },
        },


    ],
    CorporateManagement: [
        {
            title: 'Profile',
            dataIndex: 'UserProfile',
            className: "width140 textCenter",
        },
        {
            title: 'Account',
            dataIndex: 'Account',
            className: "width140",
        },
        {
            title: 'Customer Name',
            dataIndex: 'CustomerName',
            className: "width140",
        },
        {
            title: 'Phone',
            dataIndex: 'Phone',
            className: "width140",
        },
        {
            title: 'Email Address',
            dataIndex: 'EmailAddress',
            className: "width140",
        },
        {
            title: 'Cover',
            dataIndex: 'cover',
            className: "width140",
        },

        {
            title: 'Status',
            dataIndex: 'status',
            className: "width140",
        },
        {
            title: 'Action',
            dataIndex: 'corporateUserAction',
            className: "width140 textCenter",
        },

    ],
    DomesticOrderTracking: [
        {
            title: 'Created By',
            dataIndex: 'createdByName',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.createdByName != null ? a.createdByName.toString() : "";
                b = b.createdByName != null ? b.createdByName.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Tracking Number',
            dataIndex: 'trackingNumber',
            className: "width140",
            sorter: (a, b) => {
                a = a.trackingNumber != null ? a.trackingNumber.toString() : "";
                b = b.trackingNumber != null ? b.trackingNumber.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Full Name',
            dataIndex: 'attentionTo',
            className: "width140",
            sorter: (a, b) => {
                a = a.attentionTo != null ? a.attentionTo.toString() : "";
                b = b.attentionTo != null ? b.attentionTo.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Phone Numer',
            dataIndex: 'phone',
            className: "width140",
            sorter: (a, b) => {
                a = a.phone != null ? a.phone.toString() : "";
                b = b.phone != null ? b.phone.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Status',
            dataIndex: 'statusLabel',
            className: "width140",
            sorter: (a, b) => {
                a = a.statusLabel != null ? a.statusLabel.toString() : "";
                b = b.statusLabel != null ? b.statusLabel.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Last Scan',
            dataIndex: 'lastScanned',
            className: "width140",
            sorter: (a, b) => {
                a = a.lastScanned != null ? a.lastScanned.toString() : "";
                b = b.lastScanned != null ? b.lastScanned.toString() : "";
                return a.localeCompare(b);
            },
        },

        {
            title: 'Actions',
            dataIndex: 'orderTrackingAction',
            className: "width140 textCenter",
        },

    ],

    ShopInventory: [
        {
            title: '',
            dataIndex: 'productId',
            className: "custom-grid-hide-col",
        },
        {
            title: 'Sr No.',
            dataIndex: 'productId',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.productId != null ? a.productId.toString() : "";
                b = b.productId != null ? b.productId.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Product',
            dataIndex: 'name',
            className: "width140",
            sorter: (a, b) => {
                a = a.name != null ? a.name.toString() : "";
                b = b.name != null ? b.name.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Description',
            dataIndex: 'description',
            className: "width140",
            sorter: (a, b) => {
                a = a.description != null ? a.description.toString() : "";
                b = b.description != null ? b.description.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Quantity',
            dataIndex: 'quantity',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.quantity != null ? a.quantity.toString() : "";
                b = b.quantity != null ? b.quantity.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Price',
            dataIndex: 'price',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.price != null ? a.price.toString() : "";
                b = b.price != null ? b.price.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Actions',
            dataIndex: 'inventoryAction',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.Actions != null ? a.Actions.toString() : "";
                b = b.Actions != null ? b.Actions.toString() : "";
                return a.localeCompare(b);
            },
        },
    ],
    shippingDetails: [
        {
            title: 'Sr#',
            dataIndex: 't4',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.t4 != null ? a.t4.toString() : "";
                b = b.t4 != null ? b.t4.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Product',
            dataIndex: 't5',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.t5 != null ? a.t5.toString() : "";
                b = b.t5 != null ? b.t5.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Quantity',
            dataIndex: 't2',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.t2 != null ? a.t2.toString() : "";
                b = b.t2 != null ? b.t2.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Description',
            dataIndex: 't6',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.t6 != null ? a.t6.toString() : "";
                b = b.t6 != null ? b.t6.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Price',
            dataIndex: 't3',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.t3 != null ? a.t3.toString() : "";
                b = b.t3 != null ? b.t3.toString() : "";
                return a.localeCompare(b);
            },
        },

    ],
    orderList: [
        {
            title: 'Order',
            dataIndex: 'orderId',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.orderId != null ? a.orderId.toString() : "";
                b = b.orderId != null ? b.orderId.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Product Name',
            dataIndex: 'productNames',
            className: "width140",
            sorter: (a, b) => {
                a = a.productNames != null ? a.productNames.toString() : "";
                b = b.productNames != null ? b.productNames.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return <div dangerouslySetInnerHTML={{ __html: text }} />
            }
        },



        //{
        //    title: 'Product Description',
        //    dataIndex: 'ProductDescription',
        //    className: "width140 textCenter",
        //    sorter: (a, b) => {
        //        a = a.ProductDescription != null ? a.ProductDescription.toString() : "";
        //        b = b.ProductDescription != null ? b.ProductDescription.toString() : "";
        //        return a.localeCompare(b);
        //    },
        //},
        {
            title: 'Customer Name',
            dataIndex: 'customerName',
            className: "width140",
            sorter: (a, b) => {
                a = a.customerName != null ? a.customerName.toString() : "";
                b = b.customerName != null ? b.customerName.toString() : "";
                return a.localeCompare(b);
            },
        },
        // {
        //     title: 'Color',
        //     dataIndex: 'color',
        //     className: "width140 textCenter",
        //     sorter: (a, b) => {
        //         a = a.coder != null ? a.coder.toString() : "";
        //         b = b.coder != null ? b.coder.toString() : "";
        //         return a.localeCompare(b);
        //     },
        // },
        {
            title: 'Status',
            dataIndex: 'orderStatus',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.orderStatus != null ? a.orderStatus.toString() : "";
                b = b.orderStatus != null ? b.orderStatus.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Date / Time',
            dataIndex: 'createDate',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.createDate != null ? a.createDate.toString() : "";
                b = b.createDate != null ? b.createDate.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return formatDateTime(text);

            }
        },


    ],
    customerList: [
        {
            title: 'Sr #',
            dataIndex: 'orderId',
            className: "width80 textCenter",
            sorter: (a, b) => {
                a = a.orderId != null ? a.orderId.toString() : "";
                b = b.orderId != null ? b.orderId.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Customer Name',
            dataIndex: 'customerName',
            className: "width140",
            sorter: (a, b) => {
                a = a.customerName != null ? a.customerName.toString() : "";
                b = b.customerName != null ? b.customerName.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Phone',
            dataIndex: 'phone',
            className: "width140",
            sorter: (a, b) => {
                a = a.phone != null ? a.phone.toString() : "";
                b = b.phone != null ? b.phone.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Email',
            dataIndex: 'email',
            className: "width140",
            sorter: (a, b) => {
                a = a.email != null ? a.email.toString() : "";
                b = b.email != null ? b.email.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Order',
            dataIndex: 'products',
            className: "width140",
            sorter: (a, b) => {
                a = a.products != null ? a.products.toString() : "";
                b = b.products != null ? b.products.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Date',
            dataIndex: 'createDate',
            className: "width140",
            sorter: (a, b) => {
                a = a.createDate != null ? a.createDate.toString() : "";
                b = b.createDate != null ? b.createDate.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return formatDateTime(text);

            }
        },


    ],
    subscriberList: [
        //{
        //    title: 'Sr #',
        //    dataIndex: 'accountNumber',
        //    className: "width80 textCenter",
        //    sorter: (a, b) => {
        //        a = a.Sr != null ? a.Sr.toString() : "";
        //        b = b.Sr != null ? b.Sr.toString() : "";
        //        return a.localeCompare(b);
        //    },
        //},
        {
            title: 'Subscriber Name',
            dataIndex: 'customerName',
            className: "width100",
            sorter: (a, b) => {
                a = a.customerName != null ? a.customerName.toString() : "";
                b = b.customerName != null ? b.customerName.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Phone',
            dataIndex: 'phone',
            className: "width140",
            sorter: (a, b) => {
                a = a.phone != null ? a.phone.toString() : "";
                b = b.phone != null ? b.phone.toString() : "";
                return a.localeCompare(b);
            },
        },
        //{
        //    title: 'ICC',
        //    dataIndex: 'icc',
        //    className: "width140",
        //    sorter: (a, b) => {
        //        a = a.phone != null ? a.phone.toString() : "";
        //        b = b.phone != null ? b.phone.toString() : "";
        //        return a.localeCompare(b);
        //    },
        //},
        {
            title: 'Email',
            dataIndex: 'email',
            className: "width140",
            sorter: (a, b) => {
                a = a.email != null ? a.email.toString() : "";
                b = b.email != null ? b.email.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Package Expiry',
            dataIndex: 'packageExpirationDate',
            className: "width140",
            sorter: (a, b) => {
                a = a.packageExpirationDate != null ? a.packageExpirationDate.toString() : "";
                b = b.packageExpirationDate != null ? b.packageExpirationDate.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return formatDate(text);

            }
        },
        {
            title: 'Address',
            dataIndex: 'completeAddress',
            className: "width140",
            sorter: (a, b) => {
                a = a.completeAddress != null ? a.completeAddress.toString() : "";
                b = b.completeAddress != null ? b.completeAddress.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Status',
            dataIndex: 'accountStatus',
            className: "width140",
            sorter: (a, b) => {
                a = a.accountStatus != null ? a.accountStatus.toString() : "";
                b = b.accountStatus != null ? b.accountStatus.toString() : "";
                return a.localeCompare(b);
            },
        },


    ],
    dealsDiscount: [
        {
            title: 'Sr #',
            dataIndex: 'dealId',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.dealId != null ? a.dealId.toString() : "";
                b = b.dealId != null ? b.dealId.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Deal Name',
            dataIndex: 'title',
            className: "width140",
            sorter: (a, b) => {
                a = a.title != null ? a.title.toString() : "";
                b = b.title != null ? b.title.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Product Name',
            dataIndex: 'productName',
            className: "width140",
            sorter: (a, b) => {
                a = a.productName != null ? a.productName.toString() : "";
                b = b.productName != null ? b.productName.toString() : "";
                return a.localeCompare(b);
            },
        },

        {
            title: 'Discount',
            dataIndex: 'discountFormated',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.discountFormated != null ? a.discountFormated.toString() : "";
                b = b.discountFormated != null ? b.discountFormated.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Status',
            dataIndex: 'status',
            className: "width140",
            sorter: (a, b) => {
                a = a.status != null ? a.status.toString() : "";
                b = b.status != null ? b.status.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'From Date',
            dataIndex: 'fromDateFormated',
            className: "width140",
            sorter: (a, b) => {
                a = a.fromDateFormated != null ? a.fromDateFormated.toString() : "";
                b = b.fromDateFormated != null ? b.fromDateFormated.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'To Date',
            dataIndex: 'toDateFormated',
            className: "width140",
            sorter: (a, b) => {
                a = a.toDateFormated != null ? a.toDateFormated.toString() : "";
                b = b.toDateFormated != null ? b.toDateFormated.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Actions',
            dataIndex: 'dealAction',
            fixed: "right",
            className: "width140 textCenter",
        },
    ],
    orderDetails: [
        {
            title: 'Product Name',
            dataIndex: 'productName',
            className: "width140 detailProductName",
            sorter: (a, b) => {
                a = a.productName != null ? a.productName.toString() : "";
                b = b.productName != null ? b.productName.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return <Tooltip title={text}>{text}</Tooltip>;
            }
        },
        {
            title: 'Product Description',
            dataIndex: 'productDescription',
            className: "width140 detailProductName",
            sorter: (a, b) => {
                a = a.productDescription != null ? a.productDescription.toString() : "";
                b = b.productDescription != null ? b.productDescription.toString() : "";
                return a.localeCompare(b);
            },
            render: text => {
                return <Tooltip title={text}>{text.length > 20 ? text.substring(0, 20) + '...' : text}</Tooltip>;
            }
        },
        {
            title: 'Price',
            dataIndex: 'price',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.quantity != null ? a.quantity.toString() : "";
                b = b.quantity != null ? b.quantity.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Quantity',
            dataIndex: 'quantity',
            className: "width140 textCenter",
            sorter: (a, b) => {
                a = a.quantity != null ? a.quantity.toString() : "";
                b = b.quantity != null ? b.quantity.toString() : "";
                return a.localeCompare(b);
            },
        },

    ],
    CorporateListing: [
        {
            title: 'Listing Name',
            dataIndex: 'ListName',
            className: "width140",
            sorter: (a, b) => {
                a = a.ListName != null ? a.ListName.toString() : "";
                b = b.ListName != null ? b.ListName.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Status',
            dataIndex: 'ListingStatus',
            className: "width140",
            sorter: (a, b) => {
                a = a.ListingStatus != null ? a.ListingStatus.toString() : "";
                b = b.ListingStatus != null ? b.ListingStatus.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Action',
            dataIndex: 'corporateListingAction',
            className: "width140",
            sorter: (a, b) => {
                a = a.corporateListingAction != null ? a.corporateListingAction.toString() : "";
                b = b.corporateListingAction != null ? b.corporateListingAction.toString() : "";
                return a.localeCompare(b);
            },
        },
    ],
    ShipmentListing: [
        {
            title: 'ID',
            dataIndex: 'id',
            className: "width140",
            sorter: (a, b) => {
                a = a.id != null ? a.id.toString() : "";
                b = b.id != null ? b.id.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'image',
            dataIndex: 'shipmentImg',
            className: "width140",
            sorter: (a, b) => {
                a = a.shipmentImg != null ? a.shipmentImg.toString() : "";
                b = b.shipmentImg != null ? b.shipmentImg.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Status',
            dataIndex: 'status',
            className: "width140",
            sorter: (a, b) => {
                a = a.status != null ? a.status.toString() : "";
                b = b.status != null ? b.status.toString() : "";
                return a.localeCompare(b);
            },
        },
        {
            title: 'Date',
            dataIndex: 'date',
            className: "width140",
            sorter: (a, b) => {
                a = a.date != null ? a.date.toString() : "";
                b = b.date != null ? b.date.toString() : "";
                return a.localeCompare(b);
            },
        },
    ]
}