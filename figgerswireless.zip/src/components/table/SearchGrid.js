﻿import React, { useState, useEffect, useRef } from "react";

import { Button, Select, MenuItem, Popper, Grow, Paper, ClickAwayListener, Link, MenuList } from "@material-ui/core";

import Tooltip from '@material-ui/core/Tooltip';

import ArrowDropDownIcon from '@material-ui/icons/ArrowDropDown';

import { data as gridCnfg } from './setupData';

import Details from './../../assets/img/action/details.svg';
import MonthlyUsage from './../../assets/img/action/monthlyUsage.svg';
import Settings from './../../assets/img/action/settings.svg';
import ActionIcon from './../../assets/img/action/action.svg';
import ChangeName from './../../assets/img/action/changeName.svg';
import Reconnect from './../../assets/img/action/reconnect.svg';
import Disconnect from './../../assets/img/action/disconnect.svg';
import Suspend from './../../assets/img/action/suspend.svg';
import SimSwap from './../../assets/img/action/undo.svg';
import Usage from './../../assets/img/action/usage.svg';
import Forward from './../../assets/img/action/forward.svg';
import Delete from './../../assets/img/icons/Delete.svg';
import Pen from './../../assets/img/action/pen.svg';
import DeleteNoSpace from './../../assets/img/icons/DeleteNoSpace.svg';

import LoadingIcon from "./../../assets/img/icons/loaderIcon.gif";
import AddNotes from './../../assets/img/icons/addNotes.svg'
import ViewNotes from './../../assets/img/icons/eye.svg';

import LogOff from './../../assets/img/icons/LogOff.svg';
import PlayPause from './../../assets/img/icons/playPause.svg';
import NoRecord from "./../NoRecord/NoRecord";
import AddIcon from "./../../assets/img/buttonIcons/add.svg";
import ListAltIcon from '@material-ui/icons/ListAlt';
import ViewActiveLog from './../../assets/img/icons/activeLog.svg'
import { formatDate, numberDisplay } from '../../../src/components/Common/Extensions';

import { Table, Empty, Dropdown, message, Menu, Typography, Tag } from 'antd';

import useStyles from "./styles";
import './style.css';
import 'antd/dist/antd.css';




export default function SearchGrid({ onChange, selectedView, Icon, columns, onActionClick, onEditClick, onDeleteClick, onRowClick, isUpdate, list, ...props }) {
    const classes = useStyles();
    const regex = /(<([^>]+)>)/ig;

    //const listTest = [
    //    {
    //        'wirelessId': "0",,
    //        'Sr': "1",
    //        'PhoneNumber': "(941) 920-0558",
    //        'sim': "891480000006080150053",
    //        'status': "Active",
    //        'name': "Alex John",
    //        "activatedon": "Tuesday, February 22, 2018",
    //        'Forwardedto': "",
    //        'action': "",
    //    },
    //    {
    //        'wirelessId': "0",
    //        'Sr': "2",
    //        'PhoneNumber': "(941) 920-0558",
    //        'sim': "891480000006080150053",
    //        'status': "In-Active",
    //        'name': "Alex John",
    //        "activatedon": "Tuesday, February 22, 2018",
    //        'Forwardedto': "",
    //        'action': "",
    //    },
    //    {
    //        'wirelessId': "0",
    //        'Sr': "3",
    //        'PhoneNumber': "(941) 920-0558",
    //        'sim': "891480000006080150053",
    //        'name': "Alex John",
    //        "activatedon": "Tuesday, February 22, 2018",
    //        'status': "Suspended",
    //        'Forwardedto': "",
    //        'action': "",
    //    },
    //    {
    //        'wirelessId': "0",
    //        'Sr': "4",
    //        'PhoneNumber': "(941) 920-0558",
    //        'sim': "891480000006080150053",
    //        'status': "Disconnected",
    //        'name': "Alex John",
    //        "activatedon": "Tuesday, February 22, 2018",
    //        'Forwardedto': "",
    //        'action': "",
    //    },
    //    {
    //        'wirelessId': "0",
    //        'Sr': "5",
    //        'PhoneNumber': "(941) 920-0558",
    //        'sim': "891480043536080153",
    //        'status': "Hotline",
    //        'name': "Alex John",
    //        "activatedon": "Tuesday, February 22, 2018",
    //        'Forwardedto': "",
    //        'action': "",
    //    },
    //    {
    //        'wirelessId': "0",
    //        'Sr': "6",
    //        'PhoneNumber': "(941) 920-0558",
    //        'sim': "891480000006080150053",
    //        'status': "Rejected",
    //        'name': "True",
    //        "activatedon": "Tuesday, February 22, 2018",
    //        'Forwardedto': "",
    //        'action': "",
    //    },
    //    {
    //        'wirelessId': "0",
    //        'Sr': "7",
    //        'PhoneNumber': "(941) 920-0558",
    //        'sim': "891480000006080150053",
    //        'status': "Port-In-Cancel",
    //        'name': "Alex John",
    //        "activatedon": "Tuesday, February 22, 2018",
    //        'Forwardedto': "",
    //        'action': "",
    //    },

    //]

    const [rowsData, setRowsData] = useState([]);
    const [isLoading, setIsLoading] = useState(false);

    useEffect(() => {
        loadGridData();
    }, [isUpdate]);

    const items = [
        { key: 'lineDetails', label: 'Line Details', icon: Details },
        { key: 'reconnect', label: 'Reconnect', icon: Reconnect },
        { key: 'restore', label: 'Restore', icon: Reconnect },
        { key: 'usage', label: 'Usage', icon: Usage },
        { key: 'monthlyUsage', label: 'Monthly Usage', icon: MonthlyUsage },
        { key: 'changePhoneNumber', label: 'Change Phone Number', icon: Settings },
        { key: 'changeLineName', label: 'Change Line Name', icon: ChangeName },
        { key: 'forwardNumber', label: 'Forward Number', icon: Forward },
        { key: 'suspendNumber', label: 'Suspend Number', icon: Suspend },
        { key: 'customerNotes', label: 'Add Notes', icon: AddNotes },
        { key: 'viewCustomerNotes', label: 'View Notes', icon: ViewNotes },
        { key: 'viewActivityLog', label: 'View Log', icon: ViewActiveLog },
        { key: 'simSwipe', label: 'Swap SIM', icon: SimSwap },
        { key: 'imeiCheck', label: 'IMEI Check', icon: Details },
        { key: 'disconnect', label: 'Disconnect', icon: Disconnect },
    ];
    const corporateUserItems = [
        { key: 'setupUsers', label: 'Setup Users', icon: AddIcon },
        { key: 'monthToDateReport', label: 'Month To Date Report', icon: MonthlyUsage },
        { key: 'updateRecord', label: 'Update Record', icon: ChangeName },
        { key: 'killSwitch', label: 'Kill Switch', icon: LogOff },
        { key: 'playPause', label: 'Deactivate', icon: PlayPause },
    ];

    const orderTrackingAction = [
        { key: 'printLabel', label: 'Print Label', icon: AddIcon },
        { key: 'details', label: 'Details', icon: MonthlyUsage },
        { key: 'statusSummary', label: 'Status Summary', icon: ViewNotes },
        { key: 'updateRecord', label: 'Update Record', icon: ChangeName },
        { key: 'delete', label: 'Delete', icon: DeleteNoSpace },
    ];

    const dealActions = [
        { key: 'edit', label: 'Update', icon: ChangeName },
        { key: 'delete', label: 'Delete', icon: DeleteNoSpace },
    ];
    const onClick = (key, item) => {
        if (onActionClick) {
            onActionClick(key, item);
        }
        // message.info(`Click on item ${item.label}`);
    };
    const loadGridData = () => {
        if (list) {
            console.log(list)
            setRowsData(
                list.map((item, i) => {
                    item.customerInformation = <div className={classes.customerInformation}>
                        <span>
                            <Typography component="h5">Full Name: </Typography>
                            <Typography component="p">{item.fullName}</Typography>
                        </span>
                        <span>
                            <Typography component="h5">Phone #:</Typography>
                            <Typography component="p">{item.phone}</Typography>
                        </span>
                        <span>
                            <Typography component="h5">Email :</Typography>
                            <Typography component="p">{item.email}</Typography>
                        </span>
                        <span>
                            <Typography component="h5">Address :</Typography>
                            <Typography component="p">{item.address}</Typography>
                        </span>
                    </div>
                    item.orderInformation = <div className={classes.orderInformation}>
                        <span>
                            <Typography component="h5">Order Date: </Typography>
                            <Typography component="p">{item.orderDate}</Typography>
                        </span>
                        <span>
                            <Typography component="h5">Figgers Account:</Typography>
                            <Typography component="p">{item.figgersAccount}</Typography>
                        </span>
                        <span>
                            <Typography component="h5">Billing Cycle:</Typography>
                            <Typography component="p">{item.billingCycle}</Typography>
                        </span>
                        <span>
                            <Typography component="h5">Plan:</Typography>
                            <Typography component="p">{item.plan}</Typography>
                        </span>
                    </div>
                    item.requestAction = <Button className={classes.requestActionBtn}>Process</Button>

                    item.orderStatus = <Tag className={classes.requestStatusTag}>{item.orderStatus}</Tag>

                    item.prepaidAction = <div className="textCenter">
                        <Dropdown overlay={<Menu>
                            {
                                items.map((menuItem, index) => {
                                    if (
                                        (item.status == 'Disconnected' && (menuItem.key != 'reconnect' && menuItem.key != 'lineDetails' && menuItem.key != 'customerNotes' && menuItem.key != 'viewCustomerNotes' && menuItem.key != 'viewActivityLog'))
                                        || (menuItem.key == 'restore' && item.status != 'Suspended')
                                        || (menuItem.key == 'disconnect' && item.status == 'Disconnected')
                                        || (menuItem.key == 'suspendNumber' && item.status == 'Suspended')
                                        || (menuItem.key == 'reconnect' && item.status != 'Disconnected')
                                    )
                                        return ''
                                    else
                                        return <Menu.Item
                                            onClick={() => onClick(menuItem.key, item)}
                                            key={menuItem.key}
                                            className={classes.DropdownItems}
                                        > <img src={menuItem.icon} /> {menuItem.label}
                                        </Menu.Item>
                                })
                            }
                        </Menu>} trigger={["click"]}
                            className={classes.actionDropDown}>
                            <Button className={classes.actionBtn} startIcon={<img src={ActionIcon} alt="action" />}>
                                Actions <ArrowDropDownIcon />
                            </Button>
                        </Dropdown>
                    </div>
                    item.corporateUserAction = <div className="textCenter">
                        <Dropdown overlay={<Menu>
                            {
                                corporateUserItems.map((menuItem, index) => {
                                    return <Menu.Item
                                        onClick={() => onClick(menuItem.key, item)}
                                        key={menuItem.key}
                                        className={classes.DropdownItems}
                                    > <img src={menuItem.icon} /> {menuItem.label}
                                    </Menu.Item>
                                })
                            }
                        </Menu>} trigger={["click"]}
                            className={classes.actionDropDown}>
                            <Button className={classes.actionBtn} startIcon={<img src={ActionIcon} alt="action" />}>
                                Actions <ArrowDropDownIcon />
                            </Button>
                        </Dropdown>
                    </div>
                    item.postpaidAction = <div className="textCenter">
                        <Dropdown overlay={<Menu>
                            {
                                items.map((menuItem, index) => {
                                    return <Menu.Item
                                        onClick={() => onClick(menuItem.key, item)}
                                        key={menuItem.key}
                                        className={classes.DropdownItems}
                                    > <img src={menuItem.icon} /> {menuItem.label}
                                    </Menu.Item>
                                })
                            }
                        </Menu>} trigger={["click"]}
                            className={classes.actionDropDown}>
                            <Button className={classes.actionBtn} startIcon={<img src={ActionIcon} alt="action" />}>
                                Actions <ArrowDropDownIcon />
                            </Button>
                        </Dropdown>
                    </div>

                    item.orderTrackingAction = <div className="textCenter">
                        <Dropdown overlay={<Menu>
                            {
                                orderTrackingAction.map((menuItem, index) => {
                                    if ((menuItem.key == 'delete' || menuItem.key == 'updateRecord') && (item.isDeleted || item.status == "MV")) {
                                        return '';
                                    } else if (menuItem.key == 'details' && !item.orderId)
                                    {
                                        return '';
                                    }
                                    else {
                                        return <Menu.Item
                                            onClick={() => onClick(menuItem.key, item)}
                                            key={menuItem.key}
                                            className={classes.DropdownItems}
                                        > <img src={menuItem.icon} /> {menuItem.label}
                                        </Menu.Item>
                                    }
                                   
                                })
                            }
                        </Menu>} trigger={["click"]}
                            className={classes.actionDropDown}>
                            <Button className={classes.actionBtn} startIcon={<img src={ActionIcon} alt="action" />}>
                                Actions <ArrowDropDownIcon />
                            </Button>
                        </Dropdown>
                    </div>

                    item.customerNotesAction = <>

                        <div className={classes.linkContainer} style={{ justifyContent: 'center' }}>
                            {onDeleteClick ?
                                <Tooltip title="Delete">
                                    <img src={Delete} onClick={() => { onDeleteClick(item) }} />
                                </Tooltip> :
                                ''}
                        </div>

                    </>
                    item.inventoryAction = <>

                        <div className={classes.linkContainer} style={{ justifyContent: 'center' }}>
                            {onDeleteClick ?
                                <Tooltip title="Delete">
                                    <img src={Delete} onClick={() => { onDeleteClick(item) }} />
                                </Tooltip> :
                                ''}

                            {onEditClick ?
                                <Tooltip title="Edit">
                                    <img src={Pen} onClick={() => { onEditClick(item) }} />
                                </Tooltip> :
                                ''}
                        </div>
                    </>
                    item.action = <>
                        <div className={classes.linkContainer}>


                            <Tooltip title="Details">
                                <Link className={classes.actionLinkDetails} to="/">
                                    <img src={Details} />
                                </Link>
                            </Tooltip>

                            <Tooltip title="Usage">
                                <Link className={classes.actionLinkUsage} to="/">
                                    <img src={Usage} />
                                </Link>
                            </Tooltip>


                            {/*<Tooltip title="Monthly Usage">*/}
                            {/*    <Link className={classes.actionLinkMonthlyUs} to="/">*/}
                            {/*        <img src={MonthlyUsage} />*/}
                            {/*    </Link>*/}
                            {/*</Tooltip>*/}

                            <Tooltip title="Settings">
                                <Link className={classes.actionLinkMonthlySettings} to="/">
                                    <img src={Settings} />
                                </Link>
                            </Tooltip>
                        </div>

                    </>
                    item.customNoteHTML = <>
                        <Tooltip title={<p dangerouslySetInnerHTML={{
                            __html: item.customNote,
                        }}></p>}>
                            <p className={classes.truncate} dangerouslySetInnerHTML={{
                                __html: item.customNote,
                            }}></p>
                        </Tooltip>
                    </>
                    item.noteHTML = <>
                        <Tooltip title={<p dangerouslySetInnerHTML={{
                            __html: item.note,
                        }}></p>}>
                            <p dangerouslySetInnerHTML={{
                                __html: item.note,
                            }}></p>
                        </Tooltip>
                    </>

                    item.dealAction = <>

                        <div className={classes.linkContainer} style={{ justifyContent: 'center' }}>
                            <Tooltip title="Delete">
                                <img src={Delete} onClick={() => { onActionClick('Delete',item) }} />
                            </Tooltip>

                            <Tooltip title="Edit">
                                <img src={Pen} onClick={() => { onActionClick('Edit',item) }} />
                            </Tooltip>
                        </div>
                    </>

                    
                    item.statusCol = <div className="statuses"><span className={
                        item.status === "Active" ? 'activeStatus' :
                            item.status === "Inactive" ? 'inActiveStatus' :
                                item.status === "Suspended" ? 'SuspendedStatus' :
                                    item.status === "Disconnected" ? 'disconnectStatus' :
                                        item.status === "Hotlined" ? 'hotlineStatus' : ''


                    }> {item.status}</span >
                    </div>
                    { item.formattedAmount = columns == 'PaymentHistory' ? numberDisplay(item.amount, 0, 0, 0) : '' }
                    return { ...item }
                }
                ));
        }

    }
    return (
        <>
            <div className="custom-grid">
                <Table
                    // loading={true}
                    onRow={onRowClick ?
                        (record, rowIndex) => {
                            return {
                                onClick: (e) => onRowClick(record),
                                Style: 'cursor: pointer'
                            };
                        }
                        : () => { } }
                    locale={{
                        emptyText: (
                            <Empty
                                image={isLoading && LoadingIcon}
                                description={isLoading ? "Loading..." : <> <NoRecord Icon={Icon} message={props.noRecordMsg}></NoRecord> </>}
                                imageStyle={{ height: 30, display: !isLoading ? "none" : "" }}
                            />
                        )
                    }}
                    checkStrictly={true}
                    rowClassName={(record, index) => "claimRow"}
                    scroll={true}
                    pagination={{ defaultPageSize: 10, showSizeChanger: true, pageSizeOptions: [10, 20, 30, 40] }}
                    dataSource={rowsData}
                    columns={gridCnfg[columns]}
                    size="small"
                // rowSelection={isSelection ? { selectedRowKeys: selectedRows, onChange: onSelectChange } : null}
                />
            </div>
        </>
    );
}