import React, { useState, useEffect, useRef } from 'react'

import { Button, Dialog, Grid, Icon, Typography, Select, Switch, FormHelperText } from '@material-ui/core'

import Scrollbars from "rc-scrollbars";
import CloseIcon from '@material-ui/icons/Close';
import { Label } from '../../../../components/UiElements/UiElements';
import { CheckboxField, InputBaseField, TextareaField, SelectField } from '../../../../components/InputField/InputField';
import AddCircleOutlineIcon from '@material-ui/icons/AddCircleOutline';
import DragFile from "../../../../assets/img/shop/dragFile.svg";
import useStyles from "./styles";
import { PostDataAPI } from '../../../../Services/APIService';
import { withSnackbar } from "./../../../../components/Message/Alert";
import DialogLoader from '../../../../components/Loader/DialogLoader';

function AddNewItem({ dialogOpenClose, handleClose, data, ...props }) {
    const classes = useStyles();
    const [state, setState] = useState(data && data.productId > 0 ? data : { isTrackQuantity: true, isVariantAvailable: true, IsActive: true, variantType: '', lstAttachedFiles: [] });
    const { showMessage } = props;
    const [overNightShipping, setOverNightShipping] = useState(false);

    const handleOverNightShipping = (event) => {
        setOverNightShipping(event.target.checked);
    };

    const loadPreviousImages = () => {

        if (data && data.productId > 0) {
            debugger
            console.log(data.lstAttachedFiles)

            //setImages(prevItems => [...prevItems, ...fileArray]);

        }
    }

    const [images, setImages] = useState([]);

    const inputFile = useRef(null);
    const moreInputFile = useRef(null)

    const remoteItem = (index) => {
        const updatedItems = attachment.filter((_, i) => i !== index);
        setAttachment(updatedItems);
    }

    const onButtonClick = () => {
        inputFile.current.click();
    };
    const [attachment, setAttachment] = useState(state.lstAttachedFiles ? state.lstAttachedFiles:[]);

    // function uploadSingleFile(e) {
    //     const fileArray = Array.from(e.target.files);

    //     debugger
    //     console.log(fileArray)
    //     setImages(prevItems => [...prevItems, ...fileArray]);

    //     const newFiles = []
    //     for (let i = 0; i < e.target.files.length; i++) {
    //         newFiles.push(e.target.files[i].name)
    //     }
    //     //console.log(newFiles)
    //     setAttachment({
    //         files: e.target.files,
    //         fileName: newFiles ///e.target.files[0].name//.map(p => p.name).join(',')
    //     })
    // }


    function uploadSingleFile(e) {
        //const fileArray = Array.from(e.target.files);
        

       const newFiles = []
        for (let i = 0; i < e.target.files.length; i++) {
            newFiles.push({
                imgFile: e.target.files[i],
                fileName: e.target.files[i].name
            })
        }
        setAttachment(prevItems => [...prevItems, ...newFiles]);
        //setAttachment({
        //    files: e.target.files,
        //    fileName: newFiles
        //})
       
    }
    const handleChange = (e) => {
        const { name, value } = e.target;
        setState(prevState => ({
            ...prevState,
            [name]: value
        }))
    }
    const handleCheckboxChange = (e) => {
        const { name, checked } = e.target;
        setState(prevState => ({
            ...prevState,
            [name]: checked
        }))
    }


    const variantType = [
        {
            value: "",
            label: "Select Variant Type",
        },
        {
            value: "Color",
            label: "Color",
        },
        {
            value: "Size",
            label: "Size",
        },
        {
            value: "Specification",
            label: "Specification",
        }
    ]
    const [errorMessages, setErrorMessages] = useState({});
    const [isLoading, setIsLoading] = useState(false);
    const Validate = (errorList) => {
        if (!state.name) {
            setErrorMessages(prevState => ({
                ...prevState,
                errorName: true
            }));
            errorList.push(true);
        }
        else {
            setErrorMessages(prevState => ({
                ...prevState,
                errorName: false
            }));
        }

        if (!state.cost) {
            setErrorMessages(prevState => ({
                ...prevState,
                errorCost: true
            }));
            errorList.push(true);
        }
        else {
            setErrorMessages(prevState => ({
                ...prevState,
                errorCost: false
            }));
        }

        if (!state.price) {
            setErrorMessages(prevState => ({
                ...prevState,
                errorPrice: true
            }));
            errorList.push(true);
        }
        else {
            setErrorMessages(prevState => ({
                ...prevState,
                errorPrice: false
            }));
        }

        if (!state.quantity) {
            setErrorMessages(prevState => ({
                ...prevState,
                errorQuantity: true
            }));
            errorList.push(true);
        }
        else {
            setErrorMessages(prevState => ({
                ...prevState,
                errorQuantity: false
            }));
        }

    }

    const handleSelectChange = (e) => {
        const { name, value } = e.target;
        setState(prevState => ({
            ...prevState,
            [name]: value
        }))
    }
    //const [attachment, setAttachment] = useState({ files: null, fileName: null });
    const addNewItem = () => {
        //resetErrors();
        let errorList = [];
        Validate(errorList);
        if (errorList.length < 1) {
            setIsLoading(true);
            state.cost = parseFloat(state.cost);
            state.price = parseInt(state.price);
            state.quantity = parseInt(state.quantity);
            state.shippingWeight = state.shippingWeight ? parseInt(state.shippingWeight) : 0;


            const formData = new FormData();
            for (var key in state) {
                if (state[key] && key != "attachment" && key != "encUserID")
                    formData.append(key, state[key]);
            }

            if (attachment != null && attachment.length > 0) {
                for (var i = 0; i < attachment.length; i++) {
                    //formData.append("attachments" + '[' + i + ']', attachment.files[0]);
                    formData.append("attachments", attachment[i].imgFile);
                }
            }


            var method = "product/add";
            if (state.productId > 0) {
                method = "product/update";
            }
            PostDataAPI(method, formData, true, "formData").then((result) => {
                if (result.success) {
                    if (result.data) {
                        // showMessage("Success", "Line added successfully", "success", 3000);
                        handleClose();
                    }
                    else {
                        showMessage("Error", "Error adding product, please contact administrator", "error", 3000);
                    }
                }
                else {
                    showMessage("Error", result.message, "error", 3000);
                }
                setIsLoading(false);

            })
        }
    }
    useEffect(() => {
       debugger
        console.log(attachment);
    }, []);

    return (
        <>
            <Dialog
                classes={{ paper: classes.dialogPaper }}
                disableEscapeKeyDown
                open={dialogOpenClose}
                maxWidth="md"
                {...props} >
                <div className={classes.activeDialogContent}>
                    <div className={classes.box}>
                        <div className={classes.header} id="draggable-dialog-title">
                            <Typography className={classes.title}>Add/Update product</Typography>
                            <Icon className={classes.closeIcon} onClick={handleClose} color="primary"><CloseIcon /></Icon>
                        </div>

                        {isLoading ? <DialogLoader></DialogLoader> : ''}

                        <Scrollbars autoHeight autoHeightMax={540}>
                            <div className={classes.content}>

                                <Grid container>
                                    <Grid item md={8} sm={8} lg={8}>
                                        <Grid row className={classes.paddingLeftRight}>
                                            <h2>Product Details</h2>
                                            <hr style={{ opacity: '0.3' }}></hr>
                                        </Grid>
                                        <Grid row container>
                                            <Grid xl={12} md={12} sm={12} lg={12} className={classes.paddingLeftRight}>
                                                <Label title="Product Title" size={12} />
                                                <Grid xl={12} md={12} sm={12} lg={12}>
                                                    <InputBaseField
                                                        id="name"
                                                        name="name"
                                                        value={state.name}
                                                        type="text"
                                                        placeholder='Product Title'
                                                        IsDisabled={false}
                                                        onChange={handleChange}
                                                    />
                                                    {errorMessages.errorName && !state.name ? (<FormHelperText style={{ color: "red" }} >
                                                        Please enter product name
                                                    </FormHelperText>) : ('')}
                                                </Grid>

                                            </Grid>

                                            <Grid xl={12} md={12} sm={12} lg={12} className={classes.paddingLeftRight}>
                                                <Label title="Description" size={12} />
                                                <Grid xl={12} md={12} sm={12} lg={12}>
                                                    <TextareaField
                                                        id="description"
                                                        name="description"
                                                        value={state.description}
                                                        rows={6}
                                                        placeholder="Description"
                                                        MaxLength="1000"
                                                        onChange={handleChange}
                                                    ></TextareaField>
                                                </Grid>

                                            </Grid>

                                            <Grid xl={12} md={12} sm={12} lg={12} className={classes.varientLabel}>
                                                <CheckboxField
                                                    color="primary"
                                                    name="isVariantAvailable"
                                                    checked={state.isVariantAvailable}
                                                    onChange={handleCheckboxChange}
                                                    label="Variants Available"
                                                />
                                            </Grid>

                                            <Grid xl={6} md={6} sm={6} lg={6} className={classes.paddingLeftRight}>
                                                <Label title="Variant type" size={12} />
                                                <Grid xl={12} md={12} sm={12} lg={12}>
                                                    <Select
                                                        size="small"
                                                        native
                                                        name="variantType"
                                                        value={state.variantType}
                                                        onChange={handleSelectChange}
                                                        placeholder="Select"
                                                        label="Select"
                                                        className={classes.selectBaseInput}
                                                    >
                                                        {variantType.map(option =>
                                                            <option value={option.value}>{option.label}</option>
                                                        )
                                                        }
                                                    </Select>
                                                    {/*<SelectField*/}
                                                    {/*    name="variantType"*/}
                                                    {/*    id="variantType"*/}
                                                    {/*    value={state.variantType}*/}
                                                    {/*    options={variantType}*/}
                                                    {/*    onChange={handleSelectChange}*/}
                                                    {/*    placeholder={"Select variant type"}*/}
                                                    {/*/>*/}

                                                </Grid>
                                            </Grid>

                                            <Grid xl={6} md={6} sm={6} lg={6} className={classes.paddingLeftRight}>
                                                <Label title="Variant Name" size={12} />
                                                <Grid xl={12} md={12} sm={12} lg={12}>
                                                    <InputBaseField
                                                        id="variantName"
                                                        name="variantName"
                                                        type="text"
                                                        placeholder="Variant Name"
                                                        onChange={handleChange}
                                                        MaxLength='100'
                                                    />
                                                </Grid>

                                            </Grid>





                                        </Grid>

                                        <Grid row className={classes.paddingLeftRight}>
                                            <h2>Pricing</h2>
                                            <hr style={{ opacity: '0.3' }}></hr>
                                        </Grid>



                                        <Grid row container>
                                            <Grid xl={6} md={6} sm={6} lg={6} className={classes.paddingLeftRight}>
                                                <Label title="Cost" size={12} />
                                                <Grid xl={12} md={12} sm={12} lg={12}>
                                                    <InputBaseField
                                                        id="cost"
                                                        name="cost"
                                                        type="number"
                                                        value={state.cost}
                                                        placeholder="Cost"
                                                        MaxLength='10'
                                                        onChange={handleChange}
                                                    />
                                                    {errorMessages.errorCost && !state.cost ? (<FormHelperText style={{ color: "red" }} >
                                                        Please enter cost value
                                                    </FormHelperText>) : ('')}
                                                </Grid>

                                            </Grid>

                                            <Grid xl={6} md={6} sm={6} lg={6} className={classes.paddingLeftRight}>
                                                <Label title="Price" size={12} />
                                                <Grid xl={12} md={12} sm={12} lg={12}>
                                                    <InputBaseField
                                                        id="price"
                                                        name="price"
                                                        value={state.price}
                                                        type="number"
                                                        placeholder="Price"
                                                        MaxLength='10'
                                                        onChange={handleChange}
                                                    />
                                                    {errorMessages.errorPrice && !state.price ? (<FormHelperText style={{ color: "red" }} >
                                                        Please enter price value
                                                    </FormHelperText>) : ('')}
                                                </Grid>

                                            </Grid>
                                        </Grid>

                                        <Grid row container>
                                            <Grid xl={6} md={6} sm={6} lg={6} className={classes.marginCheckField}>
                                                <CheckboxField
                                                    color="primary"
                                                    name="chargeTax"
                                                    label="Charge Tax"
                                                    checked={state.chargeTax}
                                                    onChange={handleCheckboxChange}
                                                />
                                            </Grid>

                                            {/*<Grid xl={6} md={6} sm={6} lg={6} className={classes.paddingLeftRight}>*/}
                                            {/*    <Label title="Profit" size={12} />*/}
                                            {/*    <Grid xl={12} md={12} sm={12} lg={12}>*/}
                                            {/*        <InputBaseField*/}
                                            {/*            id="Profit"*/}
                                            {/*            name="Profit"*/}
                                            {/*            type="text"*/}
                                            {/*            placeholder="Auto Calculated Profit"*/}
                                            {/*            MaxLength='14'*/}
                                            {/*            onChange={handleChange}*/}
                                            {/*        />*/}
                                            {/*    </Grid>*/}

                                            {/*</Grid>*/}
                                        </Grid>


                                        <Grid row className={classes.paddingLeftRight}>
                                            <h2>Inventory</h2>
                                            <hr style={{ opacity: '0.3' }}></hr>
                                        </Grid>

                                        <Grid row container>

                                            <Grid xl={6} md={6} sm={6} lg={6} className={classes.paddingLeftRight}>
                                                <Label title="Units" size={12} />
                                                <Grid xl={12} md={12} sm={12} lg={12}>
                                                    <InputBaseField
                                                        id="quantity"
                                                        name="quantity"
                                                        value={state.quantity}
                                                        type="number"
                                                        placeholder="Units"
                                                        MaxLength='10'
                                                        onChange={handleChange}
                                                    />
                                                    {errorMessages.errorQuantity && !state.quantity ? (<FormHelperText style={{ color: "red" }} >
                                                        Please enter units value
                                                    </FormHelperText>) : ('')}
                                                </Grid>

                                            </Grid>

                                            <Grid xl={6} md={6} sm={6} lg={6} className={classes.marginCheckField}>
                                                <CheckboxField
                                                    color="primary"
                                                    name="isTrackQuantity"
                                                    checked={state.isTrackQuantity}
                                                    onChange={handleCheckboxChange}
                                                    label="Track Quantity"

                                                />
                                            </Grid>

                                        </Grid>



                                        <Grid row className={classes.paddingLeftRight}>
                                            <h2>Shipping</h2>
                                            <hr style={{ opacity: '0.3' }}></hr>
                                        </Grid>

                                        <Grid row container>

                                            <Grid xl={6} md={6} sm={6} lg={6} className={classes.paddingLeftRight}>
                                                <Label title="Shipping Weight" size={12} />
                                                <Grid xl={12} md={12} sm={12} lg={12}>
                                                    <InputBaseField
                                                        id="shippingWeight"
                                                        name="shippingWeight"
                                                        value={state.shippingWeight}
                                                        type="number"
                                                        placeholder="Weight in grams"
                                                        MaxLength='10'
                                                        onChange={handleChange}
                                                    />
                                                </Grid>

                                            </Grid>

                                            <Grid xl={6} md={6} sm={6} lg={6} className={classes.paddingLeftRight}>

                                            </Grid>

                                        </Grid>

                                    </Grid>

                                    <Grid item md={4} sm={4} lg={4}>

                                        <div className={attachment.length > 0 ? classes.multipleFiles : classes.dragFile}>

                                        {attachment && attachment.length > 0 ?
                                                <>
                                                    {<h4 className={classes.multipleFilesHead} onClick={onButtonClick} >Add more images</h4>}
                                                    <form>
                                                        <div>
                                                            <input type="file" multiple="multiple" ref={moreInputFile} className={classes.inputFile} accept=".png, .jpg, .jpeg" style={{ display: "none" }} />
                                                        </div>
                                                    </form>

                                                    <Grid container>
                                                        {attachment.map((item, index) => (
                                                            <Grid items lg={item.length == 1 ? 12 : 6} md={item.length == 1 ? 12 : 6} sm={item.length == 1 ? 12 : 6}>
                                                                <div style={{ position: 'relative' }}>
                                                                    <img
                                                                        key={index}
                                                                        src={item.imgFile ? URL.createObjectURL(item.imgFile) : '.'+item.filePath}
                                                                        alt={`Preview ${index}`}
                                                                    />
                                                                    <span className={classes.RemoveImage} onClick={() => remoteItem(index)}>x</span>

                                                                </div>
                                                            </Grid>
                                                        ))}
                                                    </Grid>
                                                </>
                                                :
                                                <>
                                                    <img className={classes.dragFileIcon} src={DragFile} onClick={onButtonClick} />
                                                    <h4 onClick={onButtonClick}>
                                                        <b style={{ color: 'rgba(77, 128, 201, 1)' }}> Browse Image </b></h4>
                                                </>
                                            }

                                            <form>
                                                <div>
                                                    <input type="file" multiple="multiple" ref={inputFile} className={classes.inputFile} onChange={uploadSingleFile} accept=".png, .jpg, .jpeg" style={{ display: "none" }} />
                                                </div>
                                            </form>

                                        </div>

                                    </Grid>

                                </Grid>


                            </div>
                        </Scrollbars>
                        <div className={classes.footer}>
                            <div className={classes.footerRight}>
                                <Button className={classes.backBtn} onClick={handleClose}>Cancel</Button>
                                <Button className={classes.changeBtn} onClick={addNewItem}>Add Items</Button>

                            </div>
                        </div>
                    </div>
                </div>
            </Dialog >
        </>
    )
}
export default withSnackbar(AddNewItem);