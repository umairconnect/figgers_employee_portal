﻿import React from "react";
import {Typography,Divider,Form,Input,Row,Button,Col,Select,DatePicker,Radio,Checkbox,Tooltip  } from "antd";
import "./styles.css"
import { useState } from "react/cjs/react.development";
import { EditOutlined } from '@ant-design/icons';
import { InputBaseField, SelectField } from "../../components/InputField/InputField";
import { CustomBtn, Label } from "../../components/UiElements/UiElements";

export default function Profile(){
    const {Option}=Select;
    const options = [
        { label: 'Male', value: 'male' },
        { label: 'Female', value: 'female' },
      ];
      const countryOptions = [
        { label: 'pakistan', value: 'Pakistan' },
        { label: 'usa', value: 'USA' },
      ];
    const [state,setState]=useState({});
    const [loading,setLoading]=useState(false);
    const [form] = Form.useForm();
    const handleChange = (e) => {
        const { name, value } = e.target;
        setState(prevState => ({
            ...prevState,
            [name]: value
        }))
    }
    const handleSelectChange=(name,value)=>{
        setState(prevState => ({
            ...prevState,
            [name]: value
        }))
    }
    const weightAfter = (
        <Select defaultValue="Lb" className="select-after" handleChange={handleSelectChange}>
            <Option value="Lb">Lb</Option>
            <Option value="Kg">Kg</Option>                                            
        </Select>
      );
      const heightAfter = (
        <Select defaultValue="Ft" className="select-after" handleChange={handleSelectChange}>
            <Option value="Ft">Ft</Option>
            <Option value="In">In</Option>                                        
        </Select>
      );

    return (
        <>
            <div className="patient-profile-main">
            <Typography className="patient-profile-title">Patient Profile</Typography>
            <Divider className="patient-profile-divider" />
            <Row>
                <Col flex={2}>
                    <img className="patient-profile-photo"  src=""
                    // src="https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png" 
                    />
                    <Tooltip title="Upload">
                        <Button className="image-upload-icon" type="primary" shape="circle" icon={<EditOutlined />} />
                    </Tooltip>
                </Col>
                <Col flex={3}>
                    <Form  className="patient-profile-custom-form" layout="vertical"  form={form} scrollToFirstError>
                        <React.Fragment>
                        
                        <Label title="Name" />
                        <InputBaseField
                            name="name" 
                            value={state.name}
                            onChange={handleChange}
                            placeholder="Name"
                            type="text"
                        />

                        <Label title="Email" />
                        <InputBaseField
                            name="email" 
                            value={state.email}
                            onChange={handleChange}
                            placeholder="Email"
                            type="email"
                        />
                        
                        <Label title="Phone #" />
                        <InputBaseField
                            name="phone" 
                            value={state.phone}
                            onChange={handleChange}
                            placeholder="Phone #"
                            type="text"
                        />

                        <Label title="Address" />
                        <InputBaseField
                            name="address" 
                            value={state.address}
                            onChange={handleChange}
                            placeholder="Address"
                            type="text"
                        />
                        <InputBaseField
                            name="address" 
                            value={state.address}
                            onChange={handleChange}
                            placeholder="Address Line 2"
                            type="text"
                        />             

                            <Row>                                
                                <Col span={12}>
                                    <Label title="City" />
                                    <InputBaseField
                                        name="city" 
                                        value={state.city}
                                        onChange={handleChange}
                                        placeholder="City"
                                        type="text"
                                    />
                                </Col>
                                <Col span={12}>
                                    <div className="div-margin-left">
                                        <Label title="Post Code" />
                                        <InputBaseField
                                            name="postCode" 
                                            value={state.postCode}
                                            onChange={handleChange}
                                            placeholder="Post Code"
                                            type="text"
                                        />
                                    </div>
                                </Col>
                                
                            </Row>

                            <Row>                                
                                
                            <Col span={12}>
                                    <Label title="State" />
                                    <InputBaseField
                                        name="state" 
                                        value={state.state}
                                        onChange={handleChange}
                                        placeholder="State"
                                        type="text"
                                    />
                                </Col>
                                <Col span={12}>
                                    <div className="div-margin-left">
                                        <Label title="Country"/>
                                        <SelectField name="country" options={options} onChange={handleSelectChange}/>
                                    </div>
                                </Col>
                                
                            </Row>

                            <Row>                                
                                <Col span={12}>
                                    <Form.Item className="patient-profile-form-item" label="DOB" name="dob" >
                                        <DatePicker className="patient-profile-input" name="dob"  />
                                    </Form.Item>
                                </Col>
                                <Col span={12}>
                                    <div className="div-margin-left">
                                        <Form.Item className="patient-profile-right-form-item"  label="Gender" name="gender"   >
                                            <Radio.Group className="patient-profile-input-right-no-box" options={options} onChange={handleChange} value={state.gender} />
                                        </Form.Item>
                                    </div>
                                </Col>
                                
                            </Row>

                            <Row>                                
                                <Col span={12}>
                                    <Form.Item className="patient-profile-form-item-custom" label="Weight" name="weight" >
                                        <Input className="dropdown-input" addonAfter={weightAfter} placeholder={`Weight`} name="weight" onChange={handleChange} />                                                                      
                                    </Form.Item> 
                                </Col>
                                <Col span={12}>
                                    <div className="div-margin-left">
                                        <Form.Item className="patient-profile-right-form-item-custom"  label="Height " name="height "   >
                                            <Input className="dropdown-input" addonAfter={heightAfter} placeholder={`Weight`} name="height" onChange={handleChange}  />   
                                        </Form.Item> 
                                    </div>
                                </Col>                            
                            </Row>

                            <Row>
                                <Label title="Insurance Company"/>
                                <SelectField name="insuranceCompany" options={options} onChange={handleSelectChange}/>
                            </Row>
                            <Row>                                
                                <Label title="Insurance Policy #" />
                                <InputBaseField
                                    name="insurancePolicyNo" 
                                    value={state.insurancePolicyNo}
                                    onChange={handleChange}
                                    placeholder="Insurance Policy #"
                                    type="text"
                                />
                                <Label title="Ins. Policy Expiry Date" />
                                <InputBaseField
                                    name="policyExpiryDate" 
                                    value={state.policyExpiryDate}
                                    onChange={handleChange}
                                    placeholder="Ins. Policy Expiry Date"
                                    type="text"
                                />
                                
                            </Row>

                            <Row>
                                <Typography className="patient-profile-title">Schedule Readings</Typography>
                                <Divider className="patient-profile-divider" />
                                <Typography className="profile-timing-note-text">* Timings can be changed from Settings</Typography>
                            </Row>
                            <Row>
                                <Col flex={12}>
                                    <Row><Checkbox value="beforeBreakfast">Before Breakfast (04:45 AM)</Checkbox></Row>                                    
                                    <Row><Checkbox value="beforeBreakfast">Before Lunch (09:45 AM)</Checkbox></Row>
                                    <Row><Checkbox value="beforeBreakfast">Before Dinner (02:45 PM)</Checkbox></Row>
                                    <Row><Checkbox value="beforeBreakfast">Bedtime (07:45 PM)</Checkbox></Row>
                                </Col>
                                <Col flex={12}>
                                    <Row><Checkbox value="beforeBreakfast">After Breakfast (07:15 AM)</Checkbox></Row>
                                    <Row><Checkbox value="beforeBreakfast">After Lunch (12:15 PM)</Checkbox></Row>
                                    <Row><Checkbox value="beforeBreakfast">After Dinner (05:15 PM)</Checkbox></Row>
                                </Col>
                            </Row>

                            <Row className="patient-profile-submit-btn">
                                <CustomBtn id="save" btnType="primary" shape="round" loading={loading} size="default" > Update</CustomBtn>
                                {/* <Button type="primary" htmlType="submit" loading={loading} className="login-form-button"> Update </Button> */}
                            </Row> 
                            
                        </React.Fragment>
                    </Form>
                </Col>
                <Col flex={2}></Col>
                <Col flex={3}></Col>
            </Row>
            {/* <Typography className="patient-profile-subtitle">Please provide your current password, enter new one  and confirm new password.</Typography>            */}
            
        </div>
        </>
    )
}