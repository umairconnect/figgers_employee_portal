import { makeStyles } from '@material-ui/core/styles';


export default makeStyles(theme => ({
    customBreadcrumbs: {
        "& a": {
            fontStyle: 'normal',
            fontWeight: 400,
            fontSize: '14px',
            lineHeight: '17px',
            color: '#5EA1BF',
        }
    },
    appBarSpacer: {
        minHeight: '82px',
        background: 'white',
    },
    header: {
        background: '#ECF2FF',
        display: 'flex',
        alignItems: 'center',
        padding: "0 15px",
        height: '58px',
        "& h1": {
            padding: '0px 15px',
            fontSize: '22px',
            fontWeight: 600,
            lineHeight: '28.8px',
            color: '#2D4D95',
        }
    },

}));