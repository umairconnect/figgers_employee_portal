import React, { lazy, Suspense, useEffect } from "react";
import {
    Grid, Drawer,
    CssBaseline,
    Box, AppBar,
    Toolbar, List,
    Typography, Divider,
    IconButton, Badge, Paper,
    Link
} from "@material-ui/core"
import useStyles from "./styles";
import Breadcrums from "../../components/BreadCrums/breadcrums";
import NoRecord from "../../components/NoRecord/NoRecord"

function DamageRepair() {
    const classes = useStyles();
    return (
        <>
            <div className={classes.appBarSpacer} />
            <div className={classes.header}>
              <Breadcrums parentLink={"Damage & Repair"}></Breadcrums>
               
            </div>

            <Grid className={classes.container}>
                <NoRecord Icon={true} message={"Coming Soon"}></NoRecord>
            </Grid>
            
            </>
    )
}
export default DamageRepair;