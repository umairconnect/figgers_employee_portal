import React, { useEffect, useState } from "react";
import {
    Grid
} from "@material-ui/core";

import TopSpacer from "../../../components/Common/spacer/TopSpacer";
import Breadcrums from "../../../components/BreadCrums/breadcrums";

import SearchGrid from "../../../components/table/SearchGrid";

import useStyles from "./styles";
import Loader from '../../../components/Loader/Loader';
import CustomerOne from "../../../assets/img/shop/customerOne.svg";
import CustomerTwo from "../../../assets/img/shop/customerTwo.svg";
import UserPlaceholder from "../../../assets/img/userPlaceholder.svg";
import Stopwatch from "../../../assets/img/icons/stopwatch.svg";
import DialogLoader from '../../../components/Loader/DialogLoader';
import { withSnackbar } from "./../../../components/Message/Alert";

import { useHistory } from "react-router-dom";
import { PostDataAPI } from '../../../Services/APIService';
import { formatDateTime, formateMdnNumber, formatDate } from './../../../components/Common/Extensions';

function Subscriber({ ...props }) {
    const classes = useStyles();
    const { showMessage } = props;
    const [filters, setFilters] = useState();
    const [isLoading, setIsLoading] = useState(false);
    const [isDataRefresh, setIsDataRefresh] = useState(false);

    const handleDataRefresh = () => {
        setIsDataRefresh(!isDataRefresh);
    }

    const [customerList, setCustomerList] = useState([
        //{
        //    Sr: "1",
        //    customerName: <> <img src={CustomerOne} /> John doe </>,
        //    phone: "202-555-0162",
        //    email: "johndoe@gmail.com",
        //    order: "4k Tv",
        //    Date: "Monday June 14",

        //},
        //{
        //    Sr: "2",
        //    customerName: <> <img src={CustomerTwo} /> Alex Hartman </>,
        //    phone: "232-555-4452",
        //    email: "alexHartman555@gmail.com",
        //    order: "Figger F3",
        //    Date: "Saturday June 20",

        //},
    ]);

    let history = useHistory();

    const handleSelectChange = (e) => {
        const { name, value } = e.target;
        setFilters(prevState => ({
            ...prevState,
            [name]: value
        }))
    }

    const loadSubscribers = () => {
        let reqData = {
            customerName: '',
            userId: ''
        }
        setIsLoading(true)
        PostDataAPI("customer/loadAllSubscibers", reqData).then((result) => {
            setIsLoading(false)
            if (result.success && result.data != null) {
                setCustomerList(
                    result.data.map((item, i) => {
                        item.customerName = <> <img className={item.photoPath ? '' : 'placeholder'} src={item.photoPath ? item.photoPath : UserPlaceholder} /> {item.firstName} </>
                        item.phone = formateMdnNumber(item.accountPhoneNumber)
                        item.expiryStatus = getExpiryStatus(item)
                        item.accountStatus = item.accountStatus == 'active'?'Active':'In Active'
                        item.completeAddress = item.homeAddress1?item.homeAddress1 + ' ' + item.homeAddress2 + ' ,' + item.homeCity + ' ' + item.homeState + ' ' + item.homeZip:''
                        return { ...item }
                    }));
                handleDataRefresh();
            }

        })
    }

    const getExpiryStatus = (item) => {
        if (!item.isPostpaid && item.packageExpirationDate) {
            return formatDate(item.packageExpirationDate);
        } else if (item.packageExpirationDate == null || !item.isPostpaid && new Date(item.packageExpirationDate) < new Date()) {
            return 'Inactive'
        } else {
            return 'Active'
        }
    }

    const [orderList, setorderList] = useState([]);


    useEffect(() => {
        loadSubscribers();
    }, []);
    return (
        <>

            <TopSpacer></TopSpacer>

            <div className={classes.header}>

                <Grid container alignItems="baseline">
                    <Grid item lg={8}>
                        <Breadcrums parentLink={"Office"} currentLink="Subscribers"></Breadcrums>
                    </Grid>
                </Grid>
                <div className={classes.rightHeader}>

                </div>
            </div>

            {isLoading ? <Loader></Loader> : ''}

            <Grid row className={classes.container}>
                <SearchGrid
                    columns="subscriberList"
                    list={customerList}
                    noRecordMsg="No subscriber exists"
                    isUpdate={isDataRefresh}
                    Icon={true}
                />

            </Grid>


        </>
    )
}
export default withSnackbar(Subscriber);