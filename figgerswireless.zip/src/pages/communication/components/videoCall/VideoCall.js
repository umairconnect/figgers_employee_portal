﻿import React, { useState, useEffect } from 'react';
import { Input, Modal, Row, Typography, Col, Avatar, message } from "antd";
import moment from 'moment';
import { Button, Dialog, Icon, Select } from '@material-ui/core';
import CloseIcon from '@material-ui/icons/Close';


//Custom Components
import { InputBaseField, SelectField } from "../../../../components/InputField/InputField";
import { Label, CustomBtn } from "../../../../components/UiElements/UiElements";
import { PostDataAPI } from '../../../../../src/Services/PostDataAPI';
// import { CommonAlerts } from "../../../../Common/CommonAlerts";
import { GetUserInfo } from '../../../../../src/Services/GetUserInfo';
import Profile from "../../../../assets/img/profilePlaceholder.jpg";
import EmailScheduleIcon from "../../../../assets/img/icons/call-email-icon.svg";
// import kaiserLogo from "../../../../images/kaiser-logo-white.png";
import { withSnackbar } from "../../../../components/Message/Alert";
import Scrollbars from 'rc-scrollbars';

//styles
import "./styles.css";
import useStyles from "./styles";




function VideoCall({ showHide, onClose, customerData, videoMeetingId, meetingHeader, showMessage, ...props }) {
    const { TextArea } = Input;
    const classes = useStyles();

    let companyId = JSON.parse(GetUserInfo()).user.companyId;
    let userID = JSON.parse(GetUserInfo()).user.userID;
    const newDate = new Date();
    const dateFormat = 'YYYY-MM-DD HH:mm:A';
    const customFormat = value => `${value.format(dateFormat)}`;

    const [loading, setLoading] = useState(false);
    const [state, setState] = useState({

        cmVideoMeetingId: 0, cmPatientId: null, cmInsuranceStaffId: null, apptDate: moment(newDate).format('YYYY-MM-DDTHH:mm'),
        apptDuration: 30, appStatus: '', appLink: '', createDate: new Date().toISOString(), isDeleted: false,
        createdBy: userID, updatedBy: 0


    });

    const [errorMessages, setErrorMessages] = useState({
        errorApptDate: false, errorApptDuration: false, errorApptInsurenceId: false
    });

    const [isUpdateGrid, setIsUpdateGrid] = useState("false");

    const [isReadOnly, setIsReadOnly] = useState(false);
    const [appointmentStaff, setAppointmentStaff] = useState([]);

    // const commonMessages = CommonAlerts();

    const durationOptions = [
        { label: '5 mins', value: 5 },
        { label: '10 mins', value: 10 },
        { label: '15 mins', value: 15 },
        { label: '20 mins', value: 20 },
        { label: '25 mins', value: 25 },
        { label: '30 mins', value: 30 },
        { label: '40 mins', value: 40 },
        { label: '50 mins', value: 50 },
        { label: '60 mins', value: 60 }
    ];


    useEffect(() => {

        //if (showHide)

        cleanValuesFields();

        if (videoMeetingId > 0) {
            loadAppointmentMeetingData();
        }
        else {
            setState(prevState => ({
                ...prevState,
                cmInsuranceStaffId: userID
            }))
        }

    }, [showHide]);

    function cleanValuesFields() {

        setState({
            cmVideoMeetingId: 0, cmPatientId: null, cmInsuranceStaffId: null,apptDate: moment(newDate).format('YYYY-MM-DDTHH:mm'),
            apptDuration: 30, appStatus: '', appLink: '', createDate: new Date().toISOString(), isDeleted: false,
            createdBy: userID, updatedBy: 0
        });

        setErrorMessages({
            errorApptDate: false, errorApptDuration: false, errorApptInsurenceId: false
        });

    }

    const handleSelectChange = (name, value) => {
        setState(prevState => ({
            ...prevState,
            [name]: value
        }))
    }


    const [actiondialogState, setActionDialogState] = useState({
        showHide: false, type: "confirm", message: "",
    })
    const showActionDialog = (message, type, OnOkCallback, OnCancellCallback) => {
        setActionDialogState(prevState => ({
            ...prevState,
            type: type,
            showHide: true,
            message: message,
            onClickOk: OnOkCallback,
            OnClickCancel: OnCancellCallback
        }));
    }

    const loadAppointmentMeetingData = () => {

        PostDataAPI("videoMeeting/getVideoMeetingById", videoMeetingId).then((result) => {

            if (result.success && result.data != null) {

                setState(result.data);
            }
        })

    }

    const handleChange = (e) => {

        const { name, value } = e.target;
        setState(prevState => ({
            ...prevState,
            [name]: value
        }))

    }

    function validateVideoMeeting(errorList) {

        if (state.apptDate === null || state.apptDate == "") {
            setErrorMessages(prevState => ({
                ...prevState,
                errorApptDate: true
            }));
            errorList.push(true);
        }
        else {
            setErrorMessages(prevState => ({
                ...prevState,
                errorApptDate: false
            }));
        }

        if (state.apptDuration === null || state.apptDuration == "") {
            setErrorMessages(prevState => ({
                ...prevState,
                errorApptDuration: true
            }));
            errorList.push(true);
        }
        else {
            setErrorMessages(prevState => ({
                ...prevState,
                errorApptDuration: false
            }));
        }

        if (state.cmInsuranceStaffId === null || state.cmInsuranceStaffId == "") {
            setErrorMessages(prevState => ({
                ...prevState,
                errorApptInsurenceId: true
            }));
            errorList.push(true);
        }
        else {
            setErrorMessages(prevState => ({
                ...prevState,
                errorApptInsurenceId: false
            }));
        }

        if (videoMeetingId > 0) {
            if (new Date(state.apptDate) < new Date()) {
                message.error("appointment date should be greater to current date and time", 3);
                errorList.push(true);
            }

        }


    }

    function saveAppointmentMeeting() {

        showMessage("Alert", "This feature is comming soon", "warning", 3000);
        return;
    };

    function disabledDate(current) {
        // Can not select days before today and today
        return current && current < moment().endOf('day');
    }

    const UpdateGrid = () => {

        setIsUpdateGrid(isUpdateGrid ? false : true);
    }

    return (
        // <Modal
        //     className="new-call-custom-modal video-call-modal"
        //     title={meetingHeader}
        //     centered
        //     visible={showHide}
        //     onCancel={onClose}
        //     maskClosable={false}
        //     width="50%"
        //     footer={
        //         [
        //             <CustomBtn
        //                 id="save"
        //                 btnType="primary"
        //                 htmlType="submit"
        //                 loading={loading}
        //                 onClick={saveAppointmentMeeting}
        //                 size="large"> Schedule Meeting
        //             </CustomBtn>
        //         ]
        //     }
        // >
        <Dialog
            classes={{ paper: classes.dialogPaper }}
            disableEscapeKeyDown
            open={showHide}
            maxWidth="lg"
            {...props} >
            <div className={classes.activeDialogContent}>
                <div className={classes.box}>
                    <div className={classes.header} id="draggable-dialog-title">
                        <Typography className={classes.title}>Schedule Video Meeting</Typography>
                        <Icon className={classes.closeIcon} onClick={onClose} color="primary"><CloseIcon /></Icon>
                    </div>
                    <Scrollbars autoHeight autoHeightMax={570}>
                        <div className={classes.content}>
                            <Row>
                                <div className="v-call-user-header">
                                    <div className="v-call-user-box">
                                        <div className="v-call-user-avatar">

                                            {/* <img alt="dp" src={customerData.patientPhotoPath ? "." + customerData.patientPhotoPath : Profile} /> */}
                                            <Avatar size={106} src={customerData?.photoPath ? "." + customerData?.photoPath : Profile} />

                                        </div>
                                        <div className="v-call-user-content">
                                            {/* <img className="kaiser-logo" alt="kaiser Logo" src={kaiserLogo} /> */}
                                            {/* <h2 className='v-call-user-heading'>Current  MDN / MSISDN</h2> */}
                                            <span class="v-call-user-title">{customerData?.fullName}</span>
                                            <div class="v-call-user-area">
                                                <span class="v-call-user-dob">{customerData?.accountNumber}</span>
                                                <span class="v-call-user-dob">
                                                    <img src={EmailScheduleIcon} alt="email" />{customerData?.email}</span>
                                                {/* <span class="v-call-user-dob">{customerData?.emailAddress}</span> */}
                                            </div>
                                            {/* <span class="v-call-user-email">{customerData?.emailAddress}</span> */}
                                            {/* {buttonTitle ? */}
                                            <div class="v-call-user-area">
                                                <span className='scheduled-date-time-text'>Scheduled Date/Time : </span>{' '}
                                                <span class="scheduled-date-time">{ ' ' + moment(state.apptDate).format("DD/MM/YYYY hh:mm A")}</span>
                                            </div>
                                            {/* :""} */}
                                        </div>
                                    </div>
                                </div>
                            </Row>
                            <Row gutter={16} className="video-call-row">
                                <Col span={12}>
                                    <Label title="Date - Time" mandatory={true} />
                                    <InputBaseField
                                        type="datetime-local"
                                        name="apptDate"
                                        id="apptDate"
                                        value={state.apptDate}
                                        onChange={handleChange}
                                        disabledDate={disabledDate}
                                        allowClear={false}
                                        min={new Date().toISOString().split('T')[0] + "T00:00"}
                                    />
                                    {
                                        errorMessages.errorApptDate && !state.apptDate ? (
                                            <Typography color="secondary" className="error-message"> Please select appointment date </Typography>
                                        ) : ("")
                                    }
                                    {/*<DatePicker
                    //    className="custom-input"
                    //    format="MM-DD-YYYY HH:mm:A"
                    //    value={state.apptDate}
                    //    showTime={{ defaultValue: moment('00:00', 'HH:mm') }}
                    //    onChange={onChange}
                    //    disabledDate={disabledDate}
                    //    allowClear={false}
                    ///>*/}
                                </Col>
                                <Col span={12}>
                                    <Label title="Duration" mandatory={true} />
                                    <SelectField name="apptDuration" options={durationOptions} value={state.apptDuration} onChange={handleSelectChange} />
                                    {/* <Select
                        size="small"
                        native
                        name="apptDuration"
                        value={state?.apptDuration}
                        onChange={handleSelectChange}
                        placeholder="Select"
                        label="Select"
                        className={classes.selectBaseInput}
                    >
                        {durationOptions.map(option =>
                            <option value={option.value}>{option.label}</option>
                        )
                        }
                    </Select> */}
                                    {/* <SelectField
                        placeholder="Select Apt. Duration"
                        name="apptDuration"
                        id="apptDuration"
                        value={state.apptDuration}
                        onChange={handleSelectChange}
                        options={durationOptions}
                        // IsDisabled={isReadOnly}
                        isClearAble={false}
                    /> */}
                                    {
                                        errorMessages.errorApptDuration && !state.apptDuration ? (
                                            <Typography color="secondary" className="error-message"> Please select appointment duration </Typography>
                                        ) : ("")
                                    }
                                </Col>
                            </Row>
                            <Row>
                                <Typography className="footer-content">
                                    SMS and email containing the meeting link will be sent to the customer.
                                </Typography>
                            </Row>
                        </div>
                    </Scrollbars>
                    <div className={classes.footer}>
                        <div className={classes.footerRight}>
                            <Button className={classes.backBtn} onClick={onClose}>Close</Button>
                            {loading ? <Button className={classes.changeBtn} >SChedule meeting</Button> :
                                <Button className={classes.changeBtn} onClick={saveAppointmentMeeting}>SChedule meeting</Button>}
                        </div>
                    </div>
                </div>
            </div>
        </Dialog >
        // {/* </Modal> */}
    )
}

export default withSnackbar(VideoCall)
