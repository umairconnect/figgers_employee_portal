import { Dialog, Grid, Icon, Typography } from '@material-ui/core'
import React, { useState, useEffect } from 'react'

import Scrollbars from "rc-scrollbars";
import CloseIcon from '@material-ui/icons/Close';

import useStyles from "./styles";
import { PostDataAPI } from '../../../../Services/APIService';
import { formatDate, formateMdnNumber } from '../../../../components/Common/Extensions';
import Loader from '../../../../components/Loader/Loader';

import DialogLoader from '../../../../components/Loader/DialogLoader';

function LineDetailsDialog({ dialogOpenClose, handleClose, isPrepaid, ...props }) {
    const classes = useStyles();
    const [accountNumber, setAccountNumber] = useState(props.accountNumber);
    const [mdnNumber, setMdnNumber] = useState(props.mdnNumber);
    const [isLoading, setIsLoading] = useState(false);
    const [state, setState] = useState({});
    const getLineDetails = () => {
        var obj = {
            MDN: mdnNumber,
            accountNumber: accountNumber,
            isPrepaid: isPrepaid
        };
        setIsLoading(true)
        PostDataAPI("telispire/getLineDetailsByMDN", obj,true).then((result) => {
            setIsLoading(false)
            if (result.success && result.data != null) {
                console.log(result.data);
                if (result.data.status == 1) {
                    result.data.status = "InActive";
                }
                else if (result.data.status == 2) {
                    result.data.status = "Active";
                }
                else if (result.data.status == 3) {
                    result.data.status = "Suspended";
                }
                else if (result.data.status == 4) {
                    result.data.status = "Disconnected";
                }
                else if (result.data.status == 6) {
                    result.data.status = "Hotlined";
                }
                else if (result.data.status == 7) {
                    result.data.status = "Rejected";
                }
                result.data.lineType = result.data.isPrepaid ? 'Prepaid' : 'Postpaid'
                setState(result.data);
            }
        })
    }
    useEffect(() => {
        console.log(props.mdnNumber)
        getLineDetails();
    }, []);
    return (
        <>

            <Dialog
                classes={{ paper: classes.dialogPaper }}
                disableBackdropClick
                disableEscapeKeyDown
                open={dialogOpenClose}
                maxWidth="lg"
                {...props} >
                <div className={classes.dialogContent}>

                    <div className={classes.box}>

                        <div className={classes.header} id="draggable-dialog-title">
                            {/* <FormGroupTitle>Figgers Coverage</FormGroupTitle> */}
                            <Typography className={classes.title}>Line Details : {formateMdnNumber(props.mdnNumber)}</Typography>
                            <Icon className={classes.closeIcon} onClick={handleClose} color="primary"><CloseIcon /></Icon>
                            {/* <span className={classes.crossButton} onClick={handleClose}><img src={CloseIcon} alt="close" /></span> */}
                        </div>
                        {isLoading ? <DialogLoader></DialogLoader> : ''}
                        <div className={classes.content}>
                      
                      
                            <Scrollbars autoHeight autoHeightMin={150} autoHeightMax={600}>
                                <Grid container row>
                                    <Grid item lg={6}>
                                        <Grid row lg={12}>
                                            <Typography className={classes.labelText}>Name:</Typography>
                                        </Grid>
                                        <Grid row lg={12}>
                                            <Typography className={classes.valueText}>{state.username}</Typography>
                                        </Grid>

                                        <Grid row lg={12}>
                                            <Typography className={classes.labelText}>Type:</Typography>
                                        </Grid>
                                        <Grid row lg={12}>
                                            <Typography className={classes.valueText}>{state.lineType}</Typography>
                                        </Grid>


                                        <Grid row lg={12}>
                                            <Typography className={classes.labelText}>Activated on:</Typography>
                                        </Grid>
                                        <Grid row lg={12}>
                                            <Typography className={classes.valueText}>{formatDate(state.activationDate)}</Typography>
                                        </Grid>

                                        <Grid row lg={12}>
                                            <Typography className={classes.labelText}>ICC /SIM</Typography>
                                        </Grid>
                                        <Grid row lg={12}>
                                            <Typography className={classes.valueText}>{state.icc}</Typography>
                                        </Grid>


                                    </Grid>


                                    <Grid item lg={6}>
                                        <Grid row lg={12}>
                                            <Typography className={classes.labelText}>Plan Name:</Typography>
                                        </Grid>
                                        <Grid row lg={12}>
                                            <Typography className={classes.valueText}>{state.ratePlan}</Typography>
                                        </Grid>

                                        <Grid row lg={12}>
                                            <Typography className={classes.labelText}>Status:</Typography>
                                        </Grid>
                                        <Grid row lg={12}>
                                            <Typography className={`${classes.valueText} ${classes.active}`}>{state.status}</Typography>
                                        </Grid>

                                        <Grid row lg={12}>
                                            <Typography className={classes.labelText}>ESN / IMEI</Typography>
                                        </Grid>
                                        <Grid row lg={12}>
                                            <Typography className={classes.valueText}>{state.esn}</Typography>
                                        </Grid>
                                    </Grid>

                                </Grid>


                            </Scrollbars>
                        </div>
                        {/* <div className={classes.footer}>

                        <div className={classes.footerRight}>

                            <CustomBtn id="save" size="medium" onClick={handleClose}  >Close</CustomBtn>

                        </div>
                    </div> */}
                    </div>
                </div>
            </Dialog >
        </>

    )
}

export default LineDetailsDialog