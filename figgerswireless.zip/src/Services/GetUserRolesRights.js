﻿
export function GetUserRolesRights() {
    return sessionStorage.getItem('user_permissions');

}