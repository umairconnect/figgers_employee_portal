﻿
export function GetUserInfo(methodName, apiParams) {
    return sessionStorage.getItem('user_info');

}