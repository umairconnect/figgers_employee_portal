﻿import { combineReducers } from 'redux';
//import { progressBarReducer } from './progressBarReducer'
//import { getLoginUserReducer } from './getLoginUserReducer';

export default combineReducers({
    //progressBarReducer: progressBarReducer,
    //getLoginUserReducer: getLoginUserReducer
})
