export const PROGRESS_BAR_STATE="PROGRESS_BAR_STATE";
export const GET="GET";
export const POST="POST";
export const PUT="PUT";
export const DELETE="DELETE";
export const ERROR="ERROR";