# Getting Started with figg-app

