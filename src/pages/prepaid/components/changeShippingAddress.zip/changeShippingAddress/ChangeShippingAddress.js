import React, { useState, useEffect } from 'react'

import { Button, Dialog, Grid, Icon, Typography, Select, FormHelperText } from '@material-ui/core'

import Scrollbars from "rc-scrollbars";
import CloseIcon from '@material-ui/icons/Close';

import DialogLoader from '../../../../components/Loader/DialogLoader';

import { InputBaseField, SelectField, TextareaField } from '../../../../components/InputField/InputField';
import { Label } from '../../../../components/UiElements/UiElements'
import { withSnackbar } from "./../../../../components/Message/Alert";
import useStyles from "./styles";

function ChangeShippingAddress({ addressType, dialogOpenClose, handleClose, ...props }) {
    const classes = useStyles();
    const [isLoading, setIsLoading] = useState(false);
    const [state, setState] = useState([]);
    const { showMessage } = props;
    const handleChange = e => {
        const { name, value } = e.target;
        setState(prevState => ({
            ...prevState,
            [name]: value
        }));
    }

    const [lstStates] = useState([
        { label: 'Please Select State', value: '' },
        { label: 'Alabama', value: 'AL' },
        { label: 'Alaska', value: 'AK' },
        { label: 'Arizona', value: 'AZ' },
        { label: 'Arkansas', value: 'AR' },
        { label: 'California', value: 'CA' },
        { label: 'Colorado', value: 'CO' },
        { label: 'Connecticut', value: 'CT' },
        { label: 'Delaware', value: 'DE' },
        { label: 'District of Columbia', value: 'DC' },
        { label: 'Florida', value: 'FL' },
        { label: 'Georgia', value: 'GA' },
        { label: 'Hawaii', value: 'HI' },
        { label: 'Idaho	', value: 'ID' },
        { label: 'Illinois', value: 'IL' },
        { label: 'Indiana', value: 'IN' },
        { label: 'Iowa', value: 'IA' },
        { label: 'Kansas', value: 'KS' },
        { label: 'Kentucky', value: 'KY' },
        { label: 'Louisiana', value: 'LA' },
        { label: 'Maine', value: 'ME' },
        { label: 'Maryland', value: 'MD' },
        { label: 'Massachusetts', value: 'MA' },
        { label: 'Michigan', value: 'MI' },
        { label: 'Minnesota', value: 'MN' },
        { label: 'Mississippi', value: 'MS' },
        { label: 'Missouri', value: 'MO' },
        { label: 'Montana', value: 'MT' },
        { label: 'Nebraska', value: 'NE' },
        { label: 'Nevada', value: 'NV' },
        { label: 'New Hampshire', value: 'NH' },
        { label: 'New Jersey', value: 'NJ' },
        { label: 'New Mexico', value: 'NM' },
        { label: 'New York', value: 'NY' },
        { label: 'North Carolina', value: 'NC' },
        { label: 'North Dakota', value: 'ND' },
        { label: 'Ohio', value: 'OH' },
        { label: 'Oklahoma', value: 'OK' },
        { label: 'Oregon', value: 'OR' },
        { label: 'Pennsylvania', value: 'PA' },
        { label: 'Rhode Island', value: 'RI' },
        { label: 'South Carolina', value: 'SC' },
        { label: 'South Dakota', value: 'SD' },
        { label: 'Tennessee', value: 'TN' },
        { label: 'Texas', value: 'TX' },
        { label: 'Utah', value: 'UT' },
        { label: 'Vermont', value: 'VT' },
        { label: 'Virginia', value: 'VA' },
        { label: 'Washington', value: 'WA' },
        { label: 'West Virginia', value: 'Va.WV' },
        { label: 'Wisconsin', value: 'WI' },
        { label: 'Wyoming', value: 'WY' }
    ]);

    const handleSelectChange = (e) => {
        const { name, value } = e.target;
        setState(prevState => ({
            ...prevState,
            [name]: value
        }))
    }


    return (
        <>

            <Dialog
                classes={{ paper: classes.dialogPaper }}
                disableBackdropClick
                disableEscapeKeyDown
                open={dialogOpenClose}
                maxWidth="lg"
                {...props} >
                <div className={classes.dialogContent}>
                    <div className={classes.box}>
                        <div className={classes.header} id="draggable-dialog-title">
                            <Typography className={classes.title}>{addressType === "shipping"? "Change Shipping Address" : "Change Home Address" }</Typography>
                            <Icon className={classes.closeIcon} onClick={handleClose} color="primary"><CloseIcon /></Icon>
                        </div>


                        {isLoading ? <DialogLoader></DialogLoader> : ''}
                        <Scrollbars autoHeight autoHeightMax={570}>
                            <div className={classes.content}>

                        


                                <Grid container spacing={2} className={classes.shippinglayout}>

                                    <Grid item sm={6} md={6} lg={6} xl={6} >
                                        <Grid row >
                                            <Label title="Name" size={2} />
                                            <InputBaseField
                                                name="shipName"
                                                value={state.shipName}
                                                onChange={handleChange}
                                                placeholder="Name"
                                                type="text"
                                                MaxLength={50}
                                            />
                                        </Grid>

                                        <Grid row >
                                            <Label title="City" size={2} />
                                            <InputBaseField
                                                name="shipCity"
                                                value={state.shipCity}
                                                onChange={handleChange}
                                                placeholder="City"
                                                type="text"
                                                MaxLength={50}
                                            />
                                        </Grid>

                                        <Grid row >
                                            <Label title="Phone" size={2} />
                                            <InputBaseField
                                                name="shipPhone"
                                                value={state.shipPhone}
                                                onChange={handleChange}
                                                placeholder="Phone"
                                                type="text"
                                                MaxLength={50}
                                            />
                                        </Grid>

                                    </Grid>

                                    <Grid item sm={6} md={6} lg={6} xl={6}>
                                        <Grid row >
                                            <Label title="Address" size={2} />
                                            <InputBaseField
                                                name="shipAddress1"
                                                value={state.shipAddress1}
                                                onChange={handleChange}
                                                placeholder="Address"
                                                type="text"
                                                MaxLength={200}
                                            />
                                        </Grid>

                                        <Grid row >
                                            <Label title="State" size={2} />
                                            
                                            <Select
                                                size="small"
                                                native
                                                name="shipState"
                                                value={state.shipState}
                                                onChange={handleSelectChange}
                                                placeholder="Select"
                                                label="Select"
                                                className={classes.selectBaseInput}
                                            >
                                                {lstStates.map(option =>
                                                    <option value={option.value}>{option.label}</option>
                                                )
                                                }
                                            </Select>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            </div>
                        </Scrollbars>
                        <div className={classes.footer}>
                            <div className={classes.footerRight}>
                                <Button className={classes.backBtn} onClick={handleClose}>Close</Button>
                                <Button className={classes.changeBtn}>Change</Button>

                            </div>
                        </div>
                    </div>
                </div>
            </Dialog >

        





        </>
    )
}

export default withSnackbar(ChangeShippingAddress);
